# LICENSES folder

This folder is where original licence and attribution files for **third-party** assets must be stored (one sub-folder per source pack).

**Currently empty of third-party licences on purpose:** this pack contains only original, script-generated art and no third-party material. See `../docs/LICENSES.md` for the full audit. When the repository owner chooses a licence for the original assets, place its text here (for example `LICENSE-assets.txt`).
