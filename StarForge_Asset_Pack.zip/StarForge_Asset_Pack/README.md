# Star-Forge Asset Pack

Game-ready PNG sprites, JSON data definitions and integration documentation for the Star-Forge 2D top-down space RPG (C17 / SDL3 / CMake / Android NDK, 320x180 internal resolution). Engine-agnostic: nothing in the engine is modified or assumed.

## What is included
| Category | Files | Highlights |
|---|---|---|
| `assets/ships` | 6 | Player Runner, Pirate Interceptor, Cargo Hauler, Civilian Transport, Military Destroyer, Military Frigate (hulls only, with empty mount pads) |
| `assets/weapons` | 6 | Laser, Pulse, Heavy Cannon, Missile Launcher, Railgun, Autocannon Turret (separate from hulls) |
| `assets/projectiles` | 6 | Blue/red laser, pulse orb, heavy shell, rail slug, missile |
| `assets/effects` | 10 sheets (46 frames, also as individual PNGs) | 4 engine exhausts, 2 muzzle flashes, 2 explosions, damage smoke, damage fire |
| `assets/asteroids` | 11 | 8 asteroids (small, large, ore) + 3 wreckage pieces |
| `assets/stations` | 1 | Ring space station |
| `assets/planets` | 5 | Terran, gas giant, moon, star, dashed orbit ring |
| `assets/salvage` | 9 | Food, Medicine, Equipment, Metal, Luxury, Fuel, Weapon salvage, generic container, large container |
| `assets/ui` | 22 | Joystick base/knob, Fire/Boost/Loot buttons (up/down), icons (health, energy, fuel, credits, inventory, weapon), reticles, selection ring, off-screen arrow, 9-slice panel and buttons |
| `assets/backgrounds` | 4 | Nebula backdrop 320x180, three parallax star tiles |
| `data/` | 33 JSON files | 6 hulls with hardpoints, 6 weapons, 6 projectiles, 10 effects, commodities, salvage container, 3 loadouts |
| `docs/` | 9 specs + CSV inventory | See below; `preview_*.png` are review aids, not game assets |
| `tools/` | | `generate_assets.py`, `generate_docs.py`, `validate_pack.py`, `make_preview.py` (Python 3 + Pillow) |

## Start here
1. `docs/ASSET_INTEGRATION.md` - loading and drawing with SDL3.
2. `docs/SPRITE_COORDINATES.md` - pivots, hardpoint maths, rotation.
3. `docs/SHIP_LAYOUT_SPEC.md`, `docs/WEAPON_MOUNTING_SPEC.md`, `docs/WEAPON_DATA_SCHEMA.md` - data-driven ships and weapons.
4. `docs/ANIMATION_SPEC.md`, `docs/ART_STYLE_GUIDE.md`, `docs/ASSET_CATALOG.md`.

## Quality assurance
`python3 tools/validate_pack.py` checks that every PNG opens and has real transparency, sizes in JSON/manifest match the files, all id and file references resolve, mount pads lie on the hull, there are no duplicate images, the example loadouts satisfy size/mount/mass/power rules, and all docs exist. Regenerate everything with `python3 tools/generate_assets.py && python3 tools/generate_docs.py`.

## Licensing
All art is original and script-generated; no third-party assets are included, so no attribution is required. **The repository owner must still choose and apply a licence** - see `docs/LICENSES.md`.

## Gaps / assets still needing original artwork
- **Battleship and Flagship hulls** (and further hull/configuration combinations) - not created, per "do not make 18 arbitrary ships".
- **Third-party high-quality art** (Kenney, OpenGameArt, itch.io) was not sourced: the build environment could not reach those sites and the Star-Forge repository was not accessible, so the existing asset pipeline could not be inspected. Verify the integration guide against your code.
- The military hulls (Destroyer, Frigate) are serviceable but plainer and rounder than the smaller ships; a human pixel artist should polish them.
- Planet surface close-ups, shields/shield-hit effects, shipyard/UI screens, fonts, sound: not included.
- Gameplay numbers in JSON (mass, power, damage, speeds, health) are consistent starting values, not balanced.
- **Fusion mechanic**: deliberately not implemented; marked as an unresolved design decision.
