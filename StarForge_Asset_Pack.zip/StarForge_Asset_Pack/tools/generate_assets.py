#!/usr/bin/env python3
"""Star-Forge asset generator (deterministic, Pillow only).

Run from anywhere:  python3 tools/generate_assets.py
Writes assets/, data/ and tools/manifest.json relative to the pack root.
All artwork is original, drawn procedurally by this script.
"""
import os, json, math, random
from PIL import Image, ImageDraw

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
MANIFEST = []

def C(h, a=255):
    h = h.lstrip('#')
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)

OUT = C('#0c0f1f')          # universal outline colour

def pal(**kw):
    return {k: C(v) for k, v in kw.items()}

PLAYER   = pal(o='#0c0f1f', d='#1a3566', s='#2457b0', m='#2f6fd1', l='#6fb6ff', h='#d8f2ff', a='#ffd24a', g='#7fffe8')
CIVIL    = pal(o='#0c0f1f', d='#4a6a63', s='#7fae9a', m='#9fd6bf', l='#d4f5e6', h='#ffffff', a='#3f9fd0', g='#ffe27a')
CARGO    = pal(o='#0c0f1f', d='#6e4219', s='#b8741f', m='#d98c2b', l='#ffc766', h='#ffe9b0', a='#2a9aa6', g='#9fe8ff')
PIRATE   = pal(o='#0c0f1f', d='#3a0c18', s='#7d1626', m='#b3202f', l='#ff6a5a', h='#ffc0a0', a='#f5b83a', g='#ffee66')
MILITARY = pal(o='#0c0f1f', d='#2e3646', s='#566178', m='#7d8aa0', l='#c3cdd9', h='#f0f4fa', a='#e0a030', g='#8fe0ff')
PAD_D, PAD_M = C('#141a2c'), C('#4a5a7e')

def new(w, h):
    return Image.new('RGBA', (w, h), (0, 0, 0, 0))

def newmask(w, h):
    m = Image.new('L', (w, h), 0)
    return m, ImageDraw.Draw(m)

def mpoly(d, w, pts):
    d.polygon(pts, fill=255)
    d.polygon([(w - 1 - x, y) for x, y in pts], fill=255)

def mrect(d, w, x0, y0, x1, y1):
    d.rectangle([x0, y0, x1, y1], fill=255)
    d.rectangle([w - 1 - x1, y0, w - 1 - x0, y1], fill=255)

def put(img, x, y, c, mirror=False):
    w, h = img.size
    if 0 <= x < w and 0 <= y < h:
        img.putpixel((x, y), c)
    if mirror and 0 <= w - 1 - x < w and 0 <= y < h:
        img.putpixel((w - 1 - x, y), c)

def inside(img, x, y):
    w, h = img.size
    if not (0 <= x < w and 0 <= y < h):
        return False
    p = img.getpixel((x, y))
    return p[3] > 0 and p != OUT

def iput(img, x, y, c, mirror=False):
    """put only on interior (non-outline, non-transparent) pixels"""
    if inside(img, x, y):
        img.putpixel((x, y), c)
    if mirror and inside(img, img.size[0] - 1 - x, y):
        img.putpixel((img.size[0] - 1 - x, y), c)

def line(img, x0, y0, x1, y1, c, mirror=False):
    dx, dy = abs(x1 - x0), -abs(y1 - y0)
    sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
    err = dx + dy
    while True:
        iput(img, x0, y0, c, mirror)
        if x0 == x1 and y0 == y1:
            break
        e2 = 2 * err
        if e2 >= dy: err += dy; x0 += sx
        if e2 <= dx: err += dx; y0 += sy

def irect(img, x0, y0, x1, y1, fill, edge=None, mirror=False):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            border = x in (x0, x1) or y in (y0, y1)
            iput(img, x, y, edge if (edge and border) else fill, mirror)

def shade(mask, p, ridge=True):
    """Outline + top-left light shading from a binary mask."""
    w, h = mask.size
    m = mask.load()
    def inm(x, y): return 0 <= x < w and 0 <= y < h and m[x, y] > 0
    edge = [[False] * w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            if m[x, y] and not (inm(x-1, y) and inm(x+1, y) and inm(x, y-1) and inm(x, y+1)):
                edge[y][x] = True
    def ise(x, y): return 0 <= x < w and 0 <= y < h and edge[y][x]
    img = new(w, h)
    for y in range(h):
        for x in range(w):
            if not m[x, y]: continue
            if edge[y][x]: img.putpixel((x, y), p['o']); continue
            if ise(x-1, y) or ise(x, y-1): c = p['l']
            elif ise(x+1, y) or ise(x, y+1): c = p['d']
            elif ridge and abs(x + 0.5 - w / 2) <= 1: c = p['l']
            elif x + 0.5 > w / 2: c = p['s']
            else: c = p['m']
            img.putpixel((x, y), c)
    return img

def draw_pads(img, hps):
    w, h = img.size
    for hp in hps:
        s = {'small': 4, 'medium': 6, 'large': 8, 'extra_large': 10}[hp['max_size']]
        px, py = w // 2 + hp['position']['x'], h // 2 + hp['position']['y']
        x0, y0 = px - s // 2, py - s // 2
        for k in range(s // 2):
            col = PAD_D if k % 2 == 0 else PAD_M
            for i in range(s - 2 * k):
                for (xx, yy) in ((x0+k+i, y0+k), (x0+k+i, y0+s-1-k), (x0+k, y0+k+i), (x0+s-1-k, y0+k+i)):
                    put(img, xx, yy, col)

def save(img, cat, name, use, frames=1, fw=None, fh=None, pivot=None, group_files=None):
    rel = f'assets/{cat}/{name}.png'
    full = os.path.join(ROOT, rel)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    img.save(full)
    MANIFEST.append(dict(category=cat, file=rel, width=img.width, height=img.height,
                         frame_w=fw or img.width, frame_h=fh or img.height, frames=frames,
                         use=use, pivot=pivot, frames_dir=group_files))

def save_strip(frames_list, cat, name, use, pivot):
    fw, fh = frames_list[0].size
    sheet = new(fw * len(frames_list), fh)
    fdir = f'assets/{cat}/frames/{name}'
    os.makedirs(os.path.join(ROOT, fdir), exist_ok=True)
    for i, f in enumerate(frames_list):
        sheet.paste(f, (i * fw, 0))
        f.save(os.path.join(ROOT, fdir, f'{name}_{i:02d}.png'))
    save(sheet, cat, name, use, len(frames_list), fw, fh, pivot, fdir)

# ----------------------------------------------------------------------------
# SHIP DEFINITIONS (single source of truth for art AND json)
# ----------------------------------------------------------------------------
def hp(id, x, y, size, mount, off=0, arc=0, restr=None):
    d = dict(id=id, position=dict(x=x, y=y), max_size=size, mount_type=mount,
             orientation_offset_deg=off, arc_deg=arc)
    if restr: d['restrictions'] = restr
    return d

def sym(id_l, id_r, x, y, size, mount, off=0, arc=0, restr=None):
    return [hp(id_l, -x, y, size, mount, -off if off else 0, arc, restr),
            hp(id_r, x, y, size, mount, off, arc, restr)]

SHIPS = {
 'ship_player_runner': dict(
    id='hull_player_runner', name='Runner Mk I', hull_class='runner', configuration='civilian', faction='player',
    size=32, exhaust_effect='fx_exhaust_blue',
    stats=dict(max_health=60, mass_empty=20, equipment_mass_capacity=24, power_output=14, cargo_capacity=8,
               fuel_capacity=100, thrust=90, max_speed=120, turn_rate_deg_s=220),
    hardpoints=sym('hp_wing_l', 'hp_wing_r', 9, 5, 'small', 'fixed') + [hp('hp_nose', 0, -2, 'medium', 'fixed')],
    exhaust=[('ex_l', -4, 13), ('ex_r', 4, 13)]),
 'ship_pirate_interceptor': dict(
    id='hull_pirate_interceptor', name='Razor Interceptor', hull_class='runner', configuration='military', faction='pirate',
    size=32, exhaust_effect='fx_exhaust_red',
    stats=dict(max_health=45, mass_empty=16, equipment_mass_capacity=14, power_output=10, cargo_capacity=2,
               fuel_capacity=60, thrust=120, max_speed=150, turn_rate_deg_s=260),
    hardpoints=sym('hp_claw_l', 'hp_claw_r', 10, -1, 'small', 'fixed'),
    exhaust=[('ex_c', 0, 14)]),
 'ship_cargo_hauler': dict(
    id='hull_cargo_hauler', name='Bulk Hauler', hull_class='corvette', configuration='cargo', faction='civilian',
    size=48, exhaust_effect='fx_exhaust_orange',
    stats=dict(max_health=140, mass_empty=80, equipment_mass_capacity=30, power_output=16, cargo_capacity=60,
               fuel_capacity=220, thrust=45, max_speed=60, turn_rate_deg_s=70),
    hardpoints=[hp('hp_nose_turret', 0, -16, 'small', 'turret', 0, 270),
                hp('hp_aft_turret', 0, 16, 'small', 'turret', 180, 270)],
    exhaust=[('ex_l', -11, 20), ('ex_c', 0, 20), ('ex_r', 11, 20)]),
 'ship_civilian_transport': dict(
    id='hull_civilian_transport', name='Starliner Transport', hull_class='corvette', configuration='civilian', faction='civilian',
    size=48, exhaust_effect='fx_exhaust_blue',
    stats=dict(max_health=90, mass_empty=60, equipment_mass_capacity=12, power_output=12, cargo_capacity=20,
               fuel_capacity=160, thrust=60, max_speed=80, turn_rate_deg_s=100),
    hardpoints=[hp('hp_dorsal', 0, -2, 'small', 'turret', 0, 300)],
    exhaust=[('ex_l', -4, 21), ('ex_r', 4, 21)]),
 'ship_military_destroyer': dict(
    id='hull_military_destroyer', name='Aegis Destroyer', hull_class='destroyer', configuration='military', faction='military',
    size=64, exhaust_effect='fx_exhaust_blue',
    stats=dict(max_health=320, mass_empty=140, equipment_mass_capacity=70, power_output=40, cargo_capacity=10,
               fuel_capacity=200, thrust=70, max_speed=95, turn_rate_deg_s=110),
    hardpoints=sym('hp_nose_l', 'hp_nose_r', 4, -12, 'medium', 'fixed') + sym('hp_wing_l', 'hp_wing_r', 15, 4, 'large', 'fixed')
               + [hp('hp_dorsal', 0, 10, 'medium', 'turret', 0, 340)],
    exhaust=[('ex_l', -8, 29), ('ex_c', 0, 29), ('ex_r', 8, 29)]),
 'ship_military_frigate': dict(
    id='hull_military_frigate', name='Bastion Frigate', hull_class='frigate', configuration='military', faction='military',
    size=96, exhaust_effect='fx_exhaust_large_blue',
    stats=dict(max_health=900, mass_empty=420, equipment_mass_capacity=220, power_output=110, cargo_capacity=40,
               fuel_capacity=400, thrust=60, max_speed=65, turn_rate_deg_s=45),
    hardpoints=[hp('hp_spine', 0, -28, 'extra_large', 'fixed', 0, 0, dict(allowed_tags=['spinal']))]
               + sym('hp_bow_l', 'hp_bow_r', 6, -12, 'large', 'fixed')
               + sym('hp_turret_fl', 'hp_turret_fr', 20, 10, 'medium', 'turret', 0, 270)
               + sym('hp_turret_al', 'hp_turret_ar', 20, 26, 'medium', 'turret', 0, 270)
               + sym('hp_pd_l', 'hp_pd_r', 8, 36, 'small', 'turret', 0, 360),
    exhaust=[('ex_l', -12, 43), ('ex_c', 0, 43), ('ex_r', 12, 43)]),
}

def draw_ship(key):
    S = SHIPS[key]; w = h = S['size']
    M, d = newmask(w, h)
    if key == 'ship_player_runner':
        P = PLAYER
        mpoly(d, w, [(15,1),(13,7),(12,12),(6,15),(1,22),(1,27),(6,25),(9,29),(15,29)])
        img = shade(M, P)
        for y in range(8, 13): put(img, 15, y, P['g'], True)
        put(img, 15, 7, P['h'], True)
        line(img, 12, 14, 7, 19, P['d'], True)
        for x, y in ((2,24),(3,24),(2,25),(3,25)): iput(img, x, y, P['a'], True)
        line(img, 14, 20, 14, 27, P['s'], True)
    elif key == 'ship_pirate_interceptor':
        P = PIRATE
        mpoly(d, w, [(15,1),(13,8),(10,10),(4,3),(2,3),(3,14),(7,22),(5,28),(9,27),(11,30),(15,30)])
        img = shade(M, P)
        for y in range(9, 13): put(img, 15, y, P['g'], True)
        line(img, 12, 12, 5, 6, P['d'], True)
        line(img, 8, 18, 4, 14, P['d'], True)
        for x, y in ((3,4),(3,5)): iput(img, x, y, P['a'], True)
        line(img, 14, 20, 14, 28, P['d'], True)
    elif key == 'ship_cargo_hauler':
        P = CARGO
        mrect(d, w, 20, 6, 23, 44); mpoly(d, w, [(23,1),(19,4),(17,10),(17,14),(23,14)])
        mrect(d, w, 8, 14, 19, 40); mrect(d, w, 10, 40, 16, 45)
        img = shade(M, P)
        for y in (7, 8): put(img, 23, y, P['g'], True)
        colsL = ['#2a9aa6', '#c4473a', '#e0b030']; colsR = ['#c4473a', '#2a9aa6', '#7bbf4a']
        for i, y0 in enumerate((16, 24, 32)):
            irect(img, 10, y0, 17, y0 + 6, C(colsL[i]), OUT)
            irect(img, w - 18, y0, w - 11, y0 + 6, C(colsR[i]), OUT)
            for yy in (y0 + 2, y0 + 4):
                line(img, 11, yy, 16, yy, C('#10141f'), False)
                line(img, w - 17, yy, w - 12, yy, C('#10141f'), False)
        line(img, 20, 16, 20, 42, P['d'], True)
    elif key == 'ship_civilian_transport':
        P = CIVIL
        mpoly(d, w, [(23,1),(19,4),(16,10),(15,20),(13,28),(6,33),(5,41),(10,42),(12,46),(23,46)])
        img = shade(M, P)
        for y in range(10, 34, 3):
            put(img, 20, y, P['g'], True); put(img, 22, y, P['g'], True)
        for y in (6, 7): put(img, 23, y, P['a'], True)
        line(img, 6, 34, 6, 40, P['a'], True); line(img, 7, 34, 7, 40, P['a'], True)
        line(img, 16, 44, 22, 44, P['d'], True)
    elif key == 'ship_military_destroyer':
        P = MILITARY
        mpoly(d, w, [(31,1),(28,6),(27,16),(22,18),(22,26),(10,28),(4,36),(3,48),(7,52),(9,58),(14,62),(31,62)])
        img = shade(M, P)
        irect(img, 28, 38, 31, 50, P['l'], P['d'], True)
        for y in (40, 42): put(img, 30, y, P['g'], True)
        for yy in (26, 34, 42, 52, 58): line(img, 12 if yy > 30 else 20, yy, 26, yy, P['d'], True)
        for x, y in ((4,36),(4,40),(4,44),(9,52),(11,57)): iput(img, x, y, P['a'], True)
        put(img, 31, 6, P['a'], True)
    elif key == 'ship_military_frigate':
        P = MILITARY
        mpoly(d, w, [(47,2),(43,12),(42,22),(37,24),(37,34),(26,36),(16,42),(9,50),(8,62),(10,76),(14,84),(18,92),(47,92)])
        img = shade(M, P)
        irect(img, 40, 58, 47, 72, P['l'], P['d'], True)
        irect(img, 43, 62, 47, 66, P['m'], P['d'], True)
        for y in (60, 64): line(img, 45, y, 47, y, P['g'], True)
        for yy in (42, 50, 58, 66, 74, 82): line(img, 10 if yy > 45 else 18, yy, 38, yy, P['d'], True)
        for y in range(46, 80, 4): iput(img, 9, y, P['a'], True)
        line(img, 47, 6, 47, 20, P['d'], True)
    draw_pads(img, S['hardpoints'])
    return img

def build_ships():
    for key, S in SHIPS.items():
        img = draw_ship(key)
        w = S['size']
        save(img, 'ships', key, f"{S['name']} ({S['hull_class']}/{S['configuration']}, {S['faction']}) hull, no weapons baked in",
             pivot=dict(x=w // 2, y=w // 2))

# ----------------------------------------------------------------------------
# WEAPONS (sprites separate from hulls; pivot = mount rotation axis)
# ----------------------------------------------------------------------------
STEEL = pal(o='#0c0f1f', d='#2e3646', s='#566178', m='#7d8aa0', l='#c3cdd9', h='#f0f4fa')

WEAPONS = {
 'wpn_laser_cannon': dict(name='Laser Cannon', size='small', mount='fixed', w=16, h=16, pivot=(8, 10), muzzle=(0, -9),
     flash='fx_muzzle_small', proj='proj_laser_blue', mass=4, power=3, eps=2, dmg=6, dtype='energy', rate=4.0, speed=300, rng=140, spread=0, tags=['energy']),
 'wpn_pulse_cannon': dict(name='Pulse Cannon', size='medium', mount='fixed', w=16, h=16, pivot=(8, 9), muzzle=(0, -8),
     flash='fx_muzzle_small', proj='proj_pulse_orb', mass=8, power=6, eps=5, dmg=12, dtype='energy', rate=2.0, speed=200, rng=120, spread=2, tags=['energy']),
 'wpn_heavy_cannon': dict(name='Heavy Cannon', size='large', mount='fixed', w=24, h=24, pivot=(12, 15), muzzle=(0, -14),
     flash='fx_muzzle_large', proj='proj_heavy_shell', mass=18, power=4, eps=3, dmg=35, dtype='kinetic', rate=0.8, speed=170, rng=150, spread=1, tags=['ballistic']),
 'wpn_missile_launcher': dict(name='Missile Launcher', size='medium', mount='fixed', w=24, h=24, pivot=(12, 12), muzzle=(0, -10),
     flash='fx_muzzle_small', proj='proj_missile', mass=12, power=3, eps=0, dmg=60, dtype='explosive', rate=0.5, speed=110, rng=180, spread=0, tags=['missile']),
 'wpn_railgun': dict(name='Railgun', size='extra_large', mount='fixed', w=24, h=40, pivot=(12, 30), muzzle=(0, -30),
     flash='fx_muzzle_large', proj='proj_rail_slug', mass=40, power=20, eps=25, dmg=120, dtype='kinetic', rate=0.33, speed=500, rng=260, spread=0, tags=['ballistic', 'spinal']),
 'wpn_turret_autocannon': dict(name='Autocannon Turret', size='small', mount='turret', w=16, h=16, pivot=(8, 8), muzzle=(0, -8),
     flash='fx_muzzle_small', proj='proj_pulse_orb', mass=6, power=3, eps=1, dmg=4, dtype='kinetic', rate=6.0, speed=240, rng=100, spread=3, tags=['ballistic'], turn=180),
}

def spr_weapon(key):
    W = WEAPONS[key]; w, h = W['w'], W['h']
    M, d = newmask(w, h)
    if key == 'wpn_laser_cannon':
        d.rectangle([6, 1, 9, 9], fill=255); d.rectangle([4, 8, 11, 13], fill=255); d.rectangle([3, 12, 12, 14], fill=255)
        img = shade(M, STEEL); put(img, 7, 2, C('#7fffe8')); put(img, 8, 2, C('#7fffe8')); put(img, 7, 3, C('#2fb8ff')); put(img, 8, 3, C('#2fb8ff'))
        line(img, 5, 10, 10, 10, STEEL['d']); put(img, 5, 13, C('#2fb8ff')); put(img, 10, 13, C('#2fb8ff'))
    elif key == 'wpn_pulse_cannon':
        d.rectangle([5, 1, 10, 4], fill=255); d.rectangle([6, 4, 9, 11], fill=255); d.rectangle([4, 10, 11, 14], fill=255)
        img = shade(M, STEEL)
        for x in range(6, 10): put(img, x, 2, C('#ffd24a'))
        put(img, 7, 1, C('#fff2a8')); put(img, 8, 1, C('#fff2a8'))
        for y in (6, 8): line(img, 6, y, 9, y, STEEL['d'])
        line(img, 5, 12, 10, 12, C('#ff9a2e'))
    elif key == 'wpn_heavy_cannon':
        d.rectangle([8, 1, 15, 4], fill=255); d.rectangle([9, 4, 14, 14], fill=255)
        d.rectangle([5, 13, 18, 20], fill=255); d.rectangle([4, 19, 19, 22], fill=255)
        img = shade(M, STEEL)
        for y in (6, 9, 12): line(img, 10, y, 13, y, STEEL['d'])
        line(img, 9, 2, 14, 2, STEEL['d']); put(img, 11, 1, C('#ffb347')); put(img, 12, 1, C('#ffb347'))
        for x, y in ((6,15),(17,15),(6,18),(17,18)): put(img, x, y, C('#e0a030'))
    elif key == 'wpn_missile_launcher':
        d.rectangle([5, 3, 18, 20], fill=255)
        img = shade(M, STEEL)
        for x0 in (7, 14):
            for y0 in (5, 12):
                irect(img, x0, y0, x0 + 2, y0 + 5, C('#1a1f30'), OUT)
                iput(img, x0 + 1, y0 + 1, C('#ff5a4a')); iput(img, x0 + 1, y0 + 2, C('#ff5a4a'))
        line(img, 11, 4, 11, 19, STEEL['d']); line(img, 12, 4, 12, 19, STEEL['d'])
    elif key == 'wpn_railgun':
        d.rectangle([6, 1, 9, 26], fill=255); d.rectangle([14, 1, 17, 26], fill=255); d.rectangle([6, 12, 17, 26], fill=255)
        d.rectangle([5, 24, 18, 36], fill=255); d.rectangle([7, 36, 16, 38], fill=255)
        img = shade(M, STEEL)
        for y in range(4, 24, 4):
            line(img, 7, y, 8, y, C('#2fb8ff')); line(img, 15, y, 16, y, C('#2fb8ff'))
        for x in (11, 12): line(img, x, 13, x, 22, C('#1a1f30'))
        for x, y in ((6,27),(17,27),(6,31),(17,31)): put(img, x, y, C('#7fffe8'))
        line(img, 8, 28, 15, 28, STEEL['d']); put(img, 7, 1, C('#7fffe8')); put(img, 8, 1, C('#7fffe8')); put(img, 15, 1, C('#7fffe8')); put(img, 16, 1, C('#7fffe8'))
    elif key == 'wpn_turret_autocannon':
        d.ellipse([2, 2, 13, 13], fill=255); d.rectangle([3, 0, 5, 6], fill=255); d.rectangle([10, 0, 12, 6], fill=255)
        img = shade(M, STEEL, ridge=False)
        irect(img, 6, 6, 9, 9, C('#2e3646'), OUT)
        put(img, 4, 1, C('#ffd24a')); put(img, 11, 1, C('#ffd24a'))
        put(img, 3, 8, C('#e0a030')); put(img, 12, 8, C('#e0a030'))
    return img

def build_weapons():
    for key, W in WEAPONS.items():
        save(spr_weapon(key), 'weapons', key, f"{W['name']} sprite ({W['size']}, {W['mount']} mount); faces up", pivot=dict(x=W['pivot'][0], y=W['pivot'][1]))

# ----------------------------------------------------------------------------
# PROJECTILES
# ----------------------------------------------------------------------------
PROJ = {
 'proj_laser_blue':  dict(name='Blue Laser Bolt', w=4, h=12, hit=2, impact='fx_explosion_small'),
 'proj_laser_red':   dict(name='Red Laser Bolt', w=4, h=12, hit=2, impact='fx_explosion_small'),
 'proj_pulse_orb':   dict(name='Pulse Orb', w=8, h=8, hit=3, impact='fx_explosion_small'),
 'proj_heavy_shell': dict(name='Heavy Shell', w=8, h=12, hit=4, impact='fx_explosion_small', blast=14),
 'proj_rail_slug':   dict(name='Railgun Slug', w=4, h=24, hit=2, impact='fx_explosion_small'),
 'proj_missile':     dict(name='Guided Missile', w=8, h=16, hit=4, impact='fx_explosion_large', blast=24, homing=dict(turn_rate_deg_s=140, acquire_cone_deg=60)),
}

def spr_proj(key):
    P = PROJ[key]; w, h = P['w'], P['h']; img = new(w, h)
    if key in ('proj_laser_blue', 'proj_laser_red'):
        col = ('#2fb8ff', '#bff4ff', '#ffffff') if key.endswith('blue') else ('#e0252f', '#ff9a8a', '#fff2ee')
        for y in range(h):
            for x in range(w):
                edge = x in (0, w - 1) or y in (0, h - 1)
                if (x in (0, 3) and y in (0, 11)): continue
                img.putpixel((x, y), C(col[0]) if edge else C(col[1]))
        for y in range(2, h - 2): put(img, 1, y, C(col[2])); 
        for y in range(2, h - 2): put(img, 2, y, C(col[2]))
    elif key == 'proj_pulse_orb':
        for (x, y) in [(x, y) for x in range(8) for y in range(8)]:
            r = math.hypot(x - 3.5, y - 3.5)
            if r <= 2.0: img.putpixel((x, y), C('#fff7c0'))
            elif r <= 3.0: img.putpixel((x, y), C('#ffb347'))
            elif r <= 4.0: img.putpixel((x, y), C('#c0471a'))
    elif key == 'proj_heavy_shell':
        d = ImageDraw.Draw(img)
        d.rectangle([2, 2, 5, 11], fill=C('#e0a030')); d.rectangle([3, 0, 4, 2], fill=C('#c3cdd9'))
        d.rectangle([2, 2, 2, 11], fill=C('#ffd98a')); d.rectangle([5, 2, 5, 11], fill=C('#8a5a18'))
        for y in (7, 8): d.line([2, y, 5, y], fill=C('#5a3a10'))
        d.rectangle([2, 10, 5, 11], fill=C('#ff9a2e'))
    elif key == 'proj_rail_slug':
        for y in range(h):
            a = 255 if y > 5 else 120 + y * 20
            put(img, 1, y, C('#bff4ff', a)); put(img, 2, y, C('#ffffff', a))
            if y > 8: put(img, 0, y, C('#2fb8ff', 160)); put(img, 3, y, C('#2fb8ff', 160))
        for y in range(0, 4): put(img, 1, y, C('#ffffff')); put(img, 2, y, C('#ffffff'))
    elif key == 'proj_missile':
        d = ImageDraw.Draw(img)
        d.rectangle([3, 2, 4, 11], fill=C('#d8dee9')); d.rectangle([3, 0, 4, 2], fill=C('#e0252f'))
        d.rectangle([4, 3, 4, 11], fill=C('#9aa5b8'))
        d.rectangle([1, 9, 2, 12], fill=C('#7d8aa0')); d.rectangle([5, 9, 6, 12], fill=C('#566178'))
        d.rectangle([3, 12, 4, 13], fill=C('#ffb347')); d.rectangle([3, 14, 4, 15], fill=C('#ff5a2e'))
        put(img, 3, 12, C('#fff7c0')); put(img, 4, 12, C('#fff7c0'))
    return img

def build_projectiles():
    for key, P in PROJ.items():
        save(spr_proj(key), 'projectiles', key, f"{P['name']}; travels along sprite's up axis", pivot=dict(x=P['w'] // 2, y=P['h'] // 2))

# ----------------------------------------------------------------------------
# ANIMATED EFFECTS
# ----------------------------------------------------------------------------
EFFECTS = {}   # id -> dict(sprite name, frames, fw, fh, frame_ms, loop, pivot, name)

def fx_exhaust(name, w, h, cols, label, frame_ms=80):
    o, m, c, wt = [C(x) for x in cols]
    frames = []
    for f in range(4):
        L = h - [0, 3, 1, 4][f]
        img = new(w, h)
        for y in range(L):
            t = y / L
            half = (w / 2) * (1 - t) ** 0.8
            for x in range(w):
                dx = abs(x + 0.5 - w / 2)
                if dx <= half:
                    inner = dx <= half * 0.35 and t < 0.6
                    mid = dx <= half * 0.7 and t < 0.8
                    col = wt if (inner and t < 0.3) else c if inner else m if mid else o
                    img.putpixel((x, y), col)
        frames.append(img)
    save_strip(frames, 'effects', name, label, dict(x=w // 2, y=0))
    EFFECTS['fx_' + name] = dict(
        sprite=name, frames=4, fw=w, fh=h, ms=frame_ms, loop=True, pivot=dict(x=w // 2, y=0), name=label)

def fx_flash(name, w, h, label):
    frames = []
    for f in range(3):
        img = new(w, h); d = ImageDraw.Draw(img)
        scale = [1.0, 0.75, 0.45][f]
        L = int((h - 2) * scale); bw = max(2, int(w * 0.4 * scale))
        cx = w // 2
        d.polygon([(cx - bw // 2 - 1, h - 2), (cx, h - 2 - L), (cx + bw // 2, h - 2)], fill=C('#ffb347'))
        d.polygon([(cx - bw // 4, h - 2), (cx, h - 2 - int(L * 0.7)), (cx + bw // 4, h - 2)], fill=C('#fff2a8'))
        d.rectangle([cx - 1, h - 4, cx, h - 2], fill=C('#ffffff'))
        sp = int(w * 0.35 * scale)
        put(img, cx - sp, h - 4 - sp // 2, C('#ffd24a')); put(img, cx + sp - 1, h - 4 - sp // 2, C('#ffd24a'))
        frames.append(img)
    save_strip(frames, 'effects', name, label, dict(x=w // 2, y=h - 2))
    EFFECTS['fx_' + name] = dict(
        sprite=name, frames=3, fw=w, fh=h, ms=40, loop=False, pivot=dict(x=w // 2, y=h - 2), name=label)

def fx_explosion(name, size, label, seed):
    rnd = random.Random(seed); N = 8; frames = []
    ph = [rnd.uniform(0, 6.28) for _ in range(4)]
    R0 = size * 0.46
    for f in range(N):
        t = f / (N - 1); img = new(size, size)
        R = R0 * (0.28 + 0.72 * math.sqrt(min(1.0, t * 1.5)))
        fade = max(0.0, (t - 0.65) / 0.35)
        for y in range(size):
            for x in range(size):
                dx, dy = x + 0.5 - size / 2, y + 0.5 - size / 2
                a = math.atan2(dy, dx)
                rr = R * (1 + 0.22 * math.sin(3 * a + ph[0]) + 0.14 * math.sin(5 * a + ph[1]) + rnd.uniform(-0.06, 0.06))
                dist = math.hypot(dx, dy)
                if dist > rr: continue
                heat = (1 - dist / rr) - t * 0.85 + rnd.uniform(-0.08, 0.08)
                if heat > 0.78: col = '#fffbe0'
                elif heat > 0.52: col = '#ffe36e'
                elif heat > 0.28: col = '#ff9a2e'
                elif heat > 0.06: col = '#d7351f'
                else: col = '#4a3038' if t > 0.35 else '#7a1d1a'
                if rnd.random() < fade * 0.85: continue
                img.putpixel((x, y), C(col))
        for _ in range(int(size / 6)):
            ang = rnd.uniform(0, 6.28); dd = R * rnd.uniform(1.0, 1.35) * (0.6 + t)
            if rnd.random() < fade: continue
            put(img, int(size / 2 + math.cos(ang) * dd), int(size / 2 + math.sin(ang) * dd), C('#ffd24a'))
        frames.append(img)
    save_strip(frames, 'effects', name, label, dict(x=size // 2, y=size // 2))
    EFFECTS['fx_' + name] = dict(
        sprite=name, frames=N, fw=size, fh=size, ms=70, loop=False, pivot=dict(x=size // 2, y=size // 2), name=label)

def fx_smoke_fire():
    rnd = random.Random(77)
    frames = []
    for f in range(4):
        img = new(16, 16)
        for i in range(5):
            r = 1.5 + i * 0.5 + f * 0.3
            cx = 8 + math.sin(i * 2.1 + f) * 2.5; cy = 13 - i * 2.4 - f * 0.8
            shade_c = ['#3a3a44', '#4e4e58', '#686874', '#84848f', '#a0a0aa'][i]
            for y in range(16):
                for x in range(16):
                    if math.hypot(x - cx, y - cy) <= r and rnd.random() > i * 0.06: img.putpixel((x, y), C(shade_c))
        frames.append(img)
    save_strip(frames, 'effects', 'damage_smoke', 'Looping smoke plume for damaged ships', dict(x=8, y=14))
    EFFECTS['fx_damage_smoke'] = dict(sprite='damage_smoke', frames=4, fw=16, fh=16, ms=140, loop=True, pivot=dict(x=8, y=14), name='Damage Smoke')
    frames = []
    for f in range(4):
        img = new(16, 16)
        for y in range(16):
            t = y / 15
            half = 5 * (t ** 0.9) * (0.85 + 0.15 * math.sin(f * 1.7 + y))
            for x in range(16):
                dx = abs(x + 0.5 - 8 + math.sin(f + y * 0.6) * 0.8)
                if dx <= half:
                    col = '#fff2a8' if dx <= half * 0.35 and t > 0.55 else '#ff9a2e' if dx <= half * 0.7 else '#d7351f'
                    img.putpixel((x, y), C(col))
        frames.append(img)
    save_strip(frames, 'effects', 'damage_fire', 'Looping flame for heavily damaged ships', dict(x=8, y=14))
    EFFECTS['fx_damage_fire'] = dict(sprite='damage_fire', frames=4, fw=16, fh=16, ms=90, loop=True, pivot=dict(x=8, y=14), name='Damage Fire')

def build_effects():
    fx_exhaust('exhaust_blue', 8, 16, ['#2457b0', '#5cd4ff', '#bff4ff', '#ffffff'], 'Blue engine exhaust (small)')
    fx_exhaust('exhaust_orange', 8, 16, ['#b3501a', '#ff9a2e', '#ffe36e', '#ffffff'], 'Orange engine exhaust (small)')
    fx_exhaust('exhaust_red', 8, 16, ['#7d1626', '#ff3d3d', '#ff9a6a', '#fff2ee'], 'Red engine exhaust (small)')
    fx_exhaust('exhaust_large_blue', 16, 32, ['#2457b0', '#5cd4ff', '#bff4ff', '#ffffff'], 'Blue engine exhaust (large)', 80)
    fx_flash('muzzle_small', 16, 16, 'Small muzzle flash')
    fx_flash('muzzle_large', 24, 24, 'Large muzzle flash')
    fx_explosion('explosion_small', 32, 'Small explosion', 11)
    fx_explosion('explosion_large', 64, 'Large explosion', 23)
    fx_smoke_fire()

# ----------------------------------------------------------------------------
# ENVIRONMENT
# ----------------------------------------------------------------------------
ROCK = {
 'grey':  ['#2a2a33', '#45444f', '#6b6975', '#9a97a3'],
 'brown': ['#2f2420', '#4d3b32', '#76604f', '#a38a73'],
 'ore':   ['#2a2d36', '#464b5c', '#6b7388', '#98a1b8'],
}

def asteroid(size, seed, tone, ore=False, craters=2):
    rnd = random.Random(seed); pl = [C(c) for c in ROCK[tone]]
    img = new(size, size); r0 = size / 2 - 1.2
    ph = [rnd.uniform(0, 6.28) for _ in range(3)]; amp = [rnd.uniform(0.08, 0.16), rnd.uniform(0.05, 0.1), rnd.uniform(0.03, 0.06)]
    mask = [[False] * size for _ in range(size)]
    for y in range(size):
        for x in range(size):
            dx, dy = x + 0.5 - size / 2, y + 0.5 - size / 2
            a = math.atan2(dy, dx)
            rr = r0 * (0.86 + amp[0] * math.sin(2 * a + ph[0]) + amp[1] * math.sin(3 * a + ph[1]) + amp[2] * math.sin(5 * a + ph[2]))
            mask[y][x] = math.hypot(dx, dy) <= rr
    def inm(x, y): return 0 <= x < size and 0 <= y < size and mask[y][x]
    cr = [(rnd.uniform(0.25, 0.75) * size, rnd.uniform(0.25, 0.75) * size, rnd.uniform(0.09, 0.16) * size) for _ in range(craters if size >= 24 else 1)]
    for y in range(size):
        for x in range(size):
            if not mask[y][x]: continue
            if not (inm(x-1, y) and inm(x+1, y) and inm(x, y-1) and inm(x, y+1)):
                img.putpixel((x, y), OUT); continue
            dx, dy = (x + 0.5 - size / 2) / r0, (y + 0.5 - size / 2) / r0
            lam = -0.55 * dx - 0.55 * dy + 0.55 + rnd.uniform(-0.12, 0.12)
            idx = 0 if lam < 0.45 else 1 if lam < 0.8 else 2 if lam < 1.1 else 3
            for (cx, cy, cr_) in cr:
                d = math.hypot(x + 0.5 - cx, y + 0.5 - cy)
                if d < cr_: idx = max(0, idx - 1) if (x - cx) + (y - cy) < 0 else min(3, idx + 1)
                elif d < cr_ + 1.0 and (x - cx) + (y - cy) > 0 and idx > 0: idx = min(3, idx + 1)
            img.putpixel((x, y), pl[idx])
    if ore:
        for _ in range(7):
            x, y = int(rnd.uniform(0.25, 0.75) * size), int(rnd.uniform(0.25, 0.75) * size)
            iput(img, x, y, C(rnd.choice(['#ffd24a', '#7fe8ff'])))
    return img

def build_asteroids():
    specs = [('asteroid_small_01', 16, 1, 'grey'), ('asteroid_small_02', 16, 2, 'brown'), ('asteroid_small_03', 24, 3, 'grey'),
             ('asteroid_large_01', 32, 4, 'brown'), ('asteroid_large_02', 32, 5, 'grey'), ('asteroid_large_03', 48, 6, 'grey'),
             ('asteroid_large_04', 48, 7, 'brown'), ('asteroid_ore_32', 32, 8, 'ore')]
    for name, s, seed, tone in specs:
        save(asteroid(s, seed, tone, ore=(tone == 'ore')), 'asteroids', name,
             f"{'Ore-bearing' if tone == 'ore' else 'Plain'} {'small' if s <= 24 else 'large'} rock", pivot=dict(x=s // 2, y=s // 2))

def build_wreckage():
    for name, s, seed in (('wreckage_small', 16, 31), ('wreckage_medium', 24, 32), ('wreckage_large', 32, 33)):
        rnd = random.Random(seed); M, d = newmask(s, s)
        for _ in range(4 if s > 16 else 3):
            cx, cy = rnd.uniform(0.28, 0.72) * s, rnd.uniform(0.28, 0.72) * s; n = rnd.randint(4, 6); r = rnd.uniform(0.14, 0.26) * s
            ang0 = rnd.uniform(0, 6.28)
            pts = [(cx + math.cos(ang0 + i * 6.28 / n) * r * rnd.uniform(0.5, 1.2), cy + math.sin(ang0 + i * 6.28 / n) * r * rnd.uniform(0.5, 1.2)) for i in range(n)]
            d.polygon(pts, fill=255)
        pm = pal(o='#0c0f1f', d='#2b2d34', s='#444852', m='#5c6170', l='#8d94a6')
        img = shade(M, pm, ridge=False)
        for _ in range(s // 4):
            x, y = rnd.randrange(s), rnd.randrange(s); iput(img, x, y, C(rnd.choice(['#16161c', '#8a4a1f', '#b3601f'])))
        for _ in range(2): iput(img, rnd.randrange(s), rnd.randrange(s), C('#e0a030'))
        save(img, 'asteroids', name, 'Ship wreckage debris (static)', pivot=dict(x=s // 2, y=s // 2))

def build_station():
    s = 96; M, d = newmask(s, s)
    d.ellipse([6, 6, 89, 89], fill=255); d.ellipse([16, 16, 79, 79], fill=0)
    d.rectangle([44, 6, 51, 89], fill=255); d.rectangle([6, 44, 89, 51], fill=255)
    d.ellipse([30, 30, 65, 65], fill=255)
    d.rectangle([0, 38, 5, 57], fill=255); d.rectangle([90, 38, 95, 57], fill=255)
    pm = pal(o='#0c0f1f', d='#2e3646', s='#566178', m='#7d8aa0', l='#c3cdd9')
    img = shade(M, pm, ridge=False)
    for y in range(s):
        for x in range(s):
            if inside(img, x, y):
                dd = math.hypot(x + 0.5 - 48, y + 0.5 - 48)
                if 38 <= dd <= 42 and (x // 3 + y // 3) % 2 == 0 and 16 < dd: iput(img, x, y, C('#2e3646'))
    for ang in range(0, 360, 12):
        x = int(48 + math.cos(math.radians(ang)) * 36); y = int(48 + math.sin(math.radians(ang)) * 36)
        iput(img, x, y, C('#ffe27a'))
    irect(img, 36, 36, 59, 59, C('#566178'), OUT)
    irect(img, 41, 41, 54, 54, C('#7d8aa0'), C('#2e3646'))
    for (x, y) in ((47, 47), (48, 47), (47, 48), (48, 48)): put(img, x, y, C('#7fe8ff'))
    for x0 in (0, 90):
        for y in range(39, 57, 3): line(img, x0 + 1, y, x0 + 4, y, C('#2457b0'))
    for (x, y) in ((47, 8), (48, 8), (47, 87), (48, 87), (8, 47), (8, 48), (87, 47), (87, 48)): iput(img, x, y, C('#ff5a4a'))
    save(img, 'stations', 'station_ring_hub', 'Ring space station with docking spokes and solar arrays', pivot=dict(x=48, y=48))

def vnoise(seed, scale):
    rnd = random.Random(seed); g = {}
    def lat(i, j):
        if (i, j) not in g: g[(i, j)] = rnd.random()
        return g[(i, j)]
    def f(x, y):
        x, y = x * scale, y * scale; i, j = math.floor(x), math.floor(y); u, v = x - i, y - j
        u, v = u * u * (3 - 2 * u), v * v * (3 - 2 * v)
        return (lat(i, j) * (1 - u) + lat(i + 1, j) * u) * (1 - v) + (lat(i, j + 1) * (1 - u) + lat(i + 1, j + 1) * u) * v
    return f

def planet(size, kind, seed):
    n1, n2 = vnoise(seed, 3.0), vnoise(seed + 5, 7.0)
    img = new(size, size); R = size / 2 - 0.5
    for y in range(size):
        for x in range(size):
            px, py = (x + 0.5 - size / 2) / R, (y + 0.5 - size / 2) / R
            r2 = px * px + py * py
            if r2 > 1: continue
            z = math.sqrt(1 - r2); lat = math.asin(py); lon = math.atan2(px, z)
            lam = -0.55 * px - 0.55 * py + 0.65 * z
            tone = 0 if lam < 0.15 else 1 if lam < 0.45 else 2 if lam < 0.75 else 3
            if kind == 'terran':
                h = n1(lon + 3, lat + 3) * 0.7 + n2(lon + 9, lat + 9) * 0.3
                land = h > 0.52
                ramps = (['#0f2a5e', '#1b4a9a', '#2f78d1', '#5aa6ee'], ['#1d4a1f', '#2f7a30', '#52a642', '#86c85a'])[land]
                if abs(lat) > 1.2: ramps = ['#8a9ab5', '#b8c6dc', '#e0eaf6', '#ffffff']
                elif n2(lon * 1.3 + 40, lat * 1.3 + 40) > 0.8: ramps = ['#9aa8bd', '#c4d0e2', '#e6eef8', '#ffffff']
                col = ramps[tone]
            elif kind == 'gas':
                b = math.sin(lat * 7 + n1(lon * 0.6, lat * 3) * 3)
                ramps = ['#6b3a1a', '#a8622a', '#d99a52', '#f2cf8a'] if b > 0.1 else ['#8a5a3a', '#c48a5a', '#ead0a0', '#fff1cc'] if b > -0.5 else ['#5a2f1a', '#8c4a22', '#b8703a', '#d99a52']
                col = ramps[tone]
                if math.hypot(lon - 0.35, lat + 0.3) < 0.28: col = ['#7d1f12', '#b53a22', '#d9603a', '#f08a5a'][tone]
            else:
                h = n2(lon + 20, lat + 20)
                ramps = ['#3a4256', '#5a6680', '#8a98b5', '#c0cce0']
                col = ramps[max(0, tone - (1 if h > 0.7 else 0))]
            img.putpixel((x, y), C(col))
    for y in range(size):
        for x in range(size):
            if img.getpixel((x, y))[3]:
                if any(not (0 <= x+dx < size and 0 <= y+dy < size) or img.getpixel((x+dx, y+dy))[3] == 0 for dx, dy in ((1,0),(-1,0),(0,1),(0,-1))):
                    img.putpixel((x, y), C('#0c0f1f') if kind == 'moon' else C('#0c0f1f'))
    return img

def build_planets():
    save(planet(64, 'terran', 3), 'planets', 'planet_terran_64', 'Ocean/land world with ice caps', pivot=dict(x=32, y=32))
    save(planet(96, 'gas', 4), 'planets', 'planet_gas_96', 'Banded gas giant with storm', pivot=dict(x=48, y=48))
    save(planet(32, 'moon', 5), 'planets', 'planet_moon_32', 'Grey-blue cratered moon', pivot=dict(x=16, y=16))
    img = new(64, 64)
    for y in range(64):
        for x in range(64):
            dd = math.hypot(x + 0.5 - 32, y + 0.5 - 32)
            if dd <= 31.5:
                t = max(0, min(1, (math.hypot(x + 0.5 - 28, y + 0.5 - 28)) / 32))
                img.putpixel((x, y), C('#fff7c0') if dd < 14 else C('#ffe36e') if dd < 22 else C('#ffb347') if dd < 28 else C('#e06a1a'))
    save(img, 'planets', 'star_yellow_64', 'Yellow main-sequence star (flat-lit disc)', pivot=dict(x=32, y=32))
    ring = new(96, 96)
    for a in range(0, 1440):
        if (a // 18) % 2 == 0:
            x = int(47.5 + math.cos(math.radians(a / 4)) * 46); y = int(47.5 + math.sin(math.radians(a / 4)) * 46)
            put(ring, x, y, C('#7fb2ff', 200))
    save(ring, 'planets', 'orbit_ring_96', 'Dashed orbit/target ring, tint at runtime', pivot=dict(x=48, y=48))

def build_backgrounds():
    rnd = random.Random(404); W, H = 320, 180; bg = Image.new('RGBA', (W, H))
    base = ['#05060f', '#070a18', '#0a0f22']; n1, n2 = vnoise(9, 3.0), vnoise(19, 6.0)
    bayer = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]
    for y in range(H):
        for x in range(W):
            v = n1(x / W, y / H) * 0.65 + n2(x / W, y / H) * 0.35
            thr = (bayer[y % 4][x % 4] + 0.5) / 16
            lvl = 0 if v < 0.45 else 1 if v < 0.60 else 2
            if lvl < 2 and v - (0.45 if lvl == 0 else 0.60) > thr * 0.08 * 6 and lvl >= 0: lvl += 0
            c = base[lvl]
            if v > 0.62 and (v - 0.62) * 8 > thr: c = '#1b1038'
            if v > 0.72 and (v - 0.72) * 8 > thr: c = '#2a1650'
            bg.putpixel((x, y), C(c))
    for _ in range(260):
        x, y = rnd.randrange(W), rnd.randrange(H); bg.putpixel((x, y), C(rnd.choice(['#4a5578', '#6b7aa0', '#8a9ac0'])))
    save(bg, 'backgrounds', 'bg_nebula_320x180', 'Static opaque nebula backdrop at internal resolution', pivot=None)
    for name, n, cols, cross in (('stars_far_128', 60, ['#3a4468', '#4a5578'], 0), ('stars_mid_128', 28, ['#6b7aa0', '#8a9ac0'], 0),
                                 ('stars_near_128', 9, ['#c8d4f0', '#ffffff', '#ffe9b0', '#bfe4ff'], 1)):
        t = new(128, 128)
        for _ in range(n):
            x, y = rnd.randrange(2, 126), rnd.randrange(2, 126); c = C(rnd.choice(cols)); t.putpixel((x, y), c)
            if cross:
                for dx, dy in ((1,0),(-1,0),(0,1),(0,-1)): t.putpixel((x + dx, y + dy), C('#6b7aa0', 150))
        save(t, 'backgrounds', name, 'Seamlessly tiling parallax star layer (transparent, points kept >=2px from edges)', pivot=None)

# ----------------------------------------------------------------------------
# SALVAGE (16x16 pickups) + large container
# ----------------------------------------------------------------------------
def finish_icon(img):
    w, h = img.size; out = img.copy()
    for y in range(h):
        for x in range(w):
            if img.getpixel((x, y))[3] == 0:
                if any(0 <= x+dx < w and 0 <= y+dy < h and img.getpixel((x+dx, y+dy))[3] > 0 for dx, dy in ((1,0),(-1,0),(0,1),(0,-1))):
                    out.putpixel((x, y), OUT)
    return out

def ell(img, box, c): ImageDraw.Draw(img).ellipse(box, fill=C(c))
def rc(img, box, c): ImageDraw.Draw(img).rectangle(box, fill=C(c))

def salvage_icon(kind):
    img = new(16, 16)
    if kind == 'food':
        ell(img, [3, 5, 12, 13], '#d7351f'); ell(img, [4, 6, 8, 9], '#ff6a5a'); rc(img, [7, 2, 8, 5], '#6e4219'); rc(img, [9, 2, 12, 3], '#52a642'); rc(img, [9, 3, 11, 4], '#2f7a30')
        for x, y in ((10, 10), (11, 9), (11, 11)): img.putpixel((x, y), C('#8a1d12'))
    elif kind == 'medicine':
        rc(img, [2, 2, 13, 13], '#e6eef8'); rc(img, [11, 3, 13, 13], '#a8b8d0'); rc(img, [3, 12, 13, 13], '#a8b8d0')
        rc(img, [6, 4, 9, 11], '#d7351f'); rc(img, [4, 6, 11, 9], '#d7351f'); rc(img, [6, 6, 7, 7], '#ff6a5a')
    elif kind == 'equipment':
        ell(img, [3, 3, 12, 12], '#7d8aa0')
        for (x, y, w_, h_) in ((6, 1, 3, 3), (6, 12, 3, 3), (1, 6, 3, 3), (12, 6, 3, 3), (2, 2, 3, 3), (11, 2, 3, 3), (2, 11, 3, 3), (11, 11, 3, 3)):
            rc(img, [x, y, x + w_ - 1, y + h_ - 1], '#7d8aa0')
        ell(img, [4, 4, 11, 11], '#a9b6c8'); ell(img, [6, 6, 9, 9], '#000000')
        for x in range(16):
            for y in range(16):
                if img.getpixel((x, y)) == (0, 0, 0, 255): img.putpixel((x, y), (0, 0, 0, 0))
        for x, y in ((5, 5), (6, 4), (4, 6)): img.putpixel((x, y), C('#dbe4f0'))
    elif kind == 'metal':
        for (x0, y0, x1) in ((1, 9, 7), (8, 9, 14), (4, 3, 11)):
            rc(img, [x0, y0, x1, y0 + 4], '#b8c2d1'); rc(img, [x0, y0, x1, y0], '#f0f4fa'); rc(img, [x0, y0 + 4, x1, y0 + 4], '#6b7388'); rc(img, [x1, y0, x1, y0 + 4], '#8a94a8')
    elif kind == 'luxury':
        ImageDraw.Draw(img).polygon([(8, 1), (14, 6), (8, 14), (2, 6)], fill=C('#b84fe0'))
        ImageDraw.Draw(img).polygon([(8, 1), (2, 6), (8, 6)], fill=C('#e0a0ff')); ImageDraw.Draw(img).polygon([(8, 6), (14, 6), (8, 14)], fill=C('#7a2ca8'))
        ImageDraw.Draw(img).line([(2, 6), (14, 6)], fill=C('#f4d8ff')); img.putpixel((5, 4), C('#ffffff'))
    elif kind == 'fuel':
        rc(img, [3, 4, 12, 14], '#e0a030'); rc(img, [3, 4, 4, 14], '#ffd98a'); rc(img, [11, 4, 12, 14], '#a8701a')
        rc(img, [3, 8, 12, 10], '#d7351f'); rc(img, [9, 1, 11, 4], '#7d8aa0'); rc(img, [4, 2, 8, 3], '#7d8aa0')
        img.putpixel((7, 12), C('#fff2a8')); img.putpixel((8, 12), C('#fff2a8'))
    elif kind == 'weapon':
        for x0 in (2, 6, 10):
            rc(img, [x0, 6, x0 + 2, 14], '#c89a3a'); rc(img, [x0, 3, x0 + 2, 6], '#d7351f'); rc(img, [x0 + 1, 2, x0 + 1, 2], '#d7351f')
            rc(img, [x0, 6, x0, 14], '#f0c868'); rc(img, [x0 + 2, 6, x0 + 2, 14], '#8a6a1a'); rc(img, [x0, 12, x0 + 2, 12], '#5a3a10')
    elif kind == 'container':
        rc(img, [1, 2, 14, 13], '#2a9aa6'); rc(img, [1, 2, 14, 3], '#7fd8e0'); rc(img, [1, 12, 14, 13], '#1a6a74')
        for x in (4, 7, 10): rc(img, [x, 4, x, 11], '#1a6a74')
        for x in (5, 8, 11): rc(img, [x, 4, x, 11], '#4ab8c4')
        rc(img, [1, 2, 2, 13], '#e0a030'); rc(img, [13, 2, 14, 13], '#e0a030')
    return finish_icon(img)

SALVAGE_ITEMS = [('food', 'Food', 'Red apple'), ('medicine', 'Medicine', 'White med-kit with red cross'), ('equipment', 'Equipment', 'Steel cog'),
                 ('metal', 'Metal', 'Stack of silver ingots'), ('luxury', 'Luxury Goods', 'Purple gemstone'), ('fuel', 'Fuel', 'Yellow canister with red band'),
                 ('weapon', 'Weapon Salvage', 'Brass ammunition cluster with red tips')]

def build_salvage():
    for k, nm, desc in SALVAGE_ITEMS:
        save(salvage_icon(k), 'salvage', f'salvage_{k}', f'{nm} pickup ({desc})', pivot=dict(x=8, y=8))
    save(salvage_icon('container'), 'salvage', 'salvage_container_generic', 'Generic cargo container pickup (teal, amber end caps)', pivot=dict(x=8, y=8))
    img = new(24, 24)
    rc(img, [1, 3, 22, 20], '#c4473a'); rc(img, [1, 3, 22, 5], '#ff8a78'); rc(img, [1, 18, 22, 20], '#7d1f1a')
    for x in range(4, 21, 3): rc(img, [x, 6, x, 17], '#7d1f1a'); rc(img, [x + 1, 6, x + 1, 17], '#e0604e')
    rc(img, [1, 3, 3, 20], '#e0b030'); rc(img, [20, 3, 22, 20], '#e0b030'); rc(img, [1, 3, 3, 4], '#ffe27a')
    save(finish_icon(img), 'salvage', 'container_large_24', 'Large drifting cargo container (red, amber end caps)', pivot=dict(x=12, y=12))

# ----------------------------------------------------------------------------
# UI
# ----------------------------------------------------------------------------
def circle(img, cx, cy, r, fill=None, outline=None, width=1):
    d = ImageDraw.Draw(img)
    d.ellipse([cx - r, cy - r, cx + r - 1, cy + r - 1], fill=fill, outline=outline, width=width)

def ui_button(color_main, color_light, color_dark, glyph, pressed):
    s = 32; img = new(s, s)
    off = 1 if pressed else 0
    circle(img, 16, 16, 16, fill=C('#0c0f1f', 230))
    circle(img, 16, 16, 14, fill=C(color_dark if pressed else color_main))
    if not pressed:
        d = ImageDraw.Draw(img); d.arc([3, 3, 28, 28], 180, 270, fill=C(color_light), width=2)
    g = C('#ffffff')
    d = ImageDraw.Draw(img)
    if glyph == 'fire':
        d.ellipse([9 + off, 9 + off, 22 + off, 22 + off], outline=g, width=2)
        d.rectangle([15 + off, 5 + off, 16 + off, 11 + off], fill=g); d.rectangle([15 + off, 20 + off, 16 + off, 26 + off], fill=g)
        d.rectangle([5 + off, 15 + off, 11 + off, 16 + off], fill=g); d.rectangle([20 + off, 15 + off, 26 + off, 16 + off], fill=g)
        d.rectangle([15 + off, 15 + off, 16 + off, 16 + off], fill=g)
    elif glyph == 'boost':
        for dy in (0, 7):
            d.polygon([(16 + off, 7 + dy + off), (23 + off, 14 + dy + off), (20 + off, 16 + dy + off), (16 + off, 12 + dy + off), (12 + off, 16 + dy + off), (9 + off, 14 + dy + off)], fill=g)
    elif glyph == 'loot':
        d.polygon([(16 + off, 21 + off), (9 + off, 13 + off), (13 + off, 13 + off), (13 + off, 6 + off), (19 + off, 6 + off), (19 + off, 13 + off), (23 + off, 13 + off)], fill=g)
        d.rectangle([8 + off, 23 + off, 24 + off, 25 + off], fill=g)
    return img

def build_ui():
    # joystick
    b = new(64, 64); circle(b, 32, 32, 32, fill=C('#0c0f1f', 110)); circle(b, 32, 32, 31, outline=C('#7fb2ff', 190), width=2)
    circle(b, 32, 32, 22, outline=C('#7fb2ff', 90), width=1)
    d = ImageDraw.Draw(b)
    for (pts) in (((32, 5), (28, 10), (36, 10)), ((32, 58), (28, 53), (36, 53)), ((5, 32), (10, 28), (10, 36)), ((58, 32), (53, 28), (53, 36))):
        d.polygon(list(pts), fill=C('#7fb2ff', 170))
    save(b, 'ui', 'ui_joystick_base', 'Virtual joystick base (semi-transparent)', pivot=dict(x=32, y=32))
    k = new(32, 32); circle(k, 16, 16, 16, fill=C('#0c0f1f', 220)); circle(k, 16, 16, 14, fill=C('#3f78d9', 235))
    ImageDraw.Draw(k).arc([3, 3, 28, 28], 180, 270, fill=C('#9fd0ff'), width=2); circle(k, 16, 16, 6, fill=C('#6fb6ff', 240))
    put(k, 11, 9, C('#d8f2ff'))
    save(k, 'ui', 'ui_joystick_knob', 'Virtual joystick knob', pivot=dict(x=16, y=16))
    for name, cols, glyph, label in (('fire', ('#d7351f', '#ff8a78', '#8a1d12'), 'fire', 'Fire'), ('boost', ('#2f78d1', '#8ac0ff', '#1b4a9a'), 'boost', 'Boost'),
                                     ('loot', ('#2f9a4a', '#8ae0a0', '#1b6a30'), 'loot', 'Loot/collect')):
        for st in ('up', 'down'):
            save(ui_button(*cols, glyph, st == 'down'), 'ui', f'ui_btn_{name}_{st}', f'{label} button, {"pressed" if st == "down" else "released"} state', pivot=dict(x=16, y=16))
    # icons 16x16
    def icon(name, label, fn):
        i = new(16, 16); fn(i); save(finish_icon(i), 'ui', f'ui_icon_{name}', label, pivot=dict(x=8, y=8))
    def heart(i):
        d = ImageDraw.Draw(i); d.ellipse([2, 3, 8, 9], fill=C('#e0252f')); d.ellipse([7, 3, 13, 9], fill=C('#e0252f'))
        d.polygon([(2, 7), (13, 7), (8, 14)], fill=C('#e0252f')); put(i, 4, 5, C('#ff9a8a')); put(i, 5, 5, C('#ff9a8a'))
        d.line([(10, 10), (8, 12)], fill=C('#a01820'))
    def bolt(i):
        ImageDraw.Draw(i).polygon([(9, 1), (3, 9), (7, 9), (6, 14), (12, 6), (8, 6)], fill=C('#ffd24a')); put(i, 8, 3, C('#fff2a8'))
    def drop(i):
        d = ImageDraw.Draw(i); d.polygon([(8, 1), (3, 8), (13, 8)], fill=C('#5cd47a')); d.ellipse([3, 6, 12, 14], fill=C('#5cd47a'))
        put(i, 5, 9, C('#d8ffe0')); put(i, 5, 10, C('#d8ffe0'))
    def coin(i):
        circle(i, 8, 8, 7, fill=C('#e0a030')); circle(i, 8, 8, 5, fill=C('#ffd24a')); circle(i, 8, 8, 3, fill=C('#e0a030'))
        put(i, 5, 5, C('#fff2a8')); put(i, 6, 5, C('#fff2a8'))
    def crate(i):
        rc(i, [2, 3, 13, 13], '#a8701a'); rc(i, [2, 3, 13, 4], '#d99a52')
        for x in (5, 9): rc(i, [x, 5, x, 12], '#6e4219')
        rc(i, [2, 8, 13, 8], '#6e4219')
    def gun(i):
        rc(i, [2, 7, 10, 10], '#7d8aa0'); rc(i, [10, 8, 14, 9], '#c3cdd9'); rc(i, [3, 10, 5, 13], '#566178'); rc(i, [2, 7, 10, 7], '#c3cdd9')
    for nm, lb, fn in (('health', 'Health (heart)', heart), ('energy', 'Energy (bolt)', bolt), ('fuel', 'Fuel (green drop)', drop),
                       ('credits', 'Credits (coin)', coin), ('inventory', 'Inventory/cargo hold (crate)', crate), ('weapon', 'Weapon slot (gun)', gun)):
        icon(nm, lb, fn)
    # reticles
    def brackets(name, color, label, lock=False):
        i = new(32, 32); c = C(color); d = ImageDraw.Draw(i)
        for (x, y, sx, sy) in ((1, 1, 1, 1), (30, 1, -1, 1), (1, 30, 1, -1), (30, 30, -1, -1)):
            d.rectangle([x, y, x + 7 * sx, y] if sx > 0 else [x + 7 * sx, y, x, y], fill=c)
            d.rectangle([x, y, x, y + 7 * sy] if sy > 0 else [x, y + 7 * sy, x, y], fill=c)
        if lock:
            d.polygon([(16, 12), (20, 16), (16, 20), (12, 16)], outline=c)
            for (x, y) in ((16, 3), (16, 28), (3, 16), (28, 16)): put(i, x, y, c)
        save(i, 'ui', name, label, pivot=dict(x=16, y=16))
    brackets('ui_reticle_target', '#ffffff', 'Target bracket (white, tint at runtime)')
    brackets('ui_reticle_lock', '#ff4a3a', 'Locked-target bracket with diamond (red)', True)
    r = new(32, 32)
    for a in range(0, 360, 20):
        if True:
            for aa in (a, a + 4, a + 8, a + 12):
                put(r, int(15.5 + math.cos(math.radians(aa)) * 14.5), int(15.5 + math.sin(math.radians(aa)) * 14.5), C('#6dff9a'))
    save(r, 'ui', 'ui_selection_ring', 'Dashed selection ring (green)', pivot=dict(x=16, y=16))
    a = new(16, 16)
    ImageDraw.Draw(a).polygon([(8, 1), (14, 13), (8, 10), (2, 13)], fill=C('#ffd24a'))
    save(finish_icon(a), 'ui', 'ui_offscreen_arrow', 'Off-screen target arrow (points up; rotate at runtime)', pivot=dict(x=8, y=8))
    # panels (9-slice 24x24)
    def panel(name, fill, edge, hi, label, a=235):
        i = new(24, 24); d = ImageDraw.Draw(i)
        d.rectangle([0, 0, 23, 23], fill=C('#0c0f1f')); d.rectangle([1, 1, 22, 22], fill=C(edge)); d.rectangle([2, 2, 21, 21], fill=C(fill, a))
        d.line([(2, 2), (21, 2)], fill=C(hi)); d.line([(2, 2), (2, 21)], fill=C(hi))
        for (x, y) in ((0, 0), (23, 0), (0, 23), (23, 23)): i.putpixel((x, y), (0, 0, 0, 0))
        save(i, 'ui', name, label, pivot=None)
    panel('ui_panel_9slice', '#121a2e', '#3b5a9a', '#5a82c8', 'Panel background, 9-slice (margins 6 px)')
    panel('ui_button_9slice_normal', '#2a4a8a', '#7fb2ff', '#a8d0ff', 'Button background normal, 9-slice (margins 6 px)', 255)
    panel('ui_button_9slice_pressed', '#1a2f5a', '#5a82c8', '#3b5a9a', 'Button background pressed, 9-slice (margins 6 px)', 255)
    panel('ui_button_9slice_disabled', '#2a2f3a', '#555b6a', '#6b7388', 'Button background disabled, 9-slice (margins 6 px)', 255)

# ----------------------------------------------------------------------------
# JSON DATA
# ----------------------------------------------------------------------------
def wj(rel, obj):
    p = os.path.join(ROOT, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, 'w') as f: json.dump(obj, f, indent=2); f.write('\n')

def sprite_ref(cat, name, w, h, pivot=None):
    d = dict(file=f'assets/{cat}/{name}.png', width=w, height=h)
    if pivot: d['pivot'] = pivot
    return d

def build_data():
    for key, S in SHIPS.items():
        w = S['size']
        wj(f'data/ships/{key}.json', dict(
            schema_version=1, id=S['id'], display_name=S['name'], hull_class=S['hull_class'], configuration=S['configuration'], faction=S['faction'],
            sprite=sprite_ref('ships', key, w, w, dict(x=w // 2, y=w // 2)), stats=S['stats'],
            exhaust_points=[dict(id=i, position=dict(x=x, y=y), effect_id=S['exhaust_effect']) for (i, x, y) in S['exhaust']],
            hardpoints=S['hardpoints']))
    for key, W in WEAPONS.items():
        o = dict(schema_version=1, id=key, display_name=W['name'], size=W['size'], mount_type=W['mount'],
                 sprite=sprite_ref('weapons', key, W['w'], W['h'], dict(x=W['pivot'][0], y=W['pivot'][1])),
                 muzzle=dict(offset=dict(x=W['muzzle'][0], y=W['muzzle'][1]), flash_effect_id=W['flash']),
                 projectile_id=W['proj'], mass=W['mass'], power_draw=W['power'], energy_per_shot=W['eps'],
                 damage=W['dmg'], damage_type=W['dtype'], fire_rate=W['rate'], projectile_speed=W['speed'], range=W['rng'],
                 spread_deg=W['spread'], tags=W['tags'])
        if 'turn' in W: o['turret_turn_rate_deg_s'] = W['turn']
        wj(f'data/weapons/{key}.json', o)
    for key, P in PROJ.items():
        o = dict(schema_version=1, id=key, display_name=P['name'], sprite=sprite_ref('projectiles', key, P['w'], P['h'], dict(x=P['w'] // 2, y=P['h'] // 2)),
                 hit_radius=P['hit'], impact_effect_id=P['impact'])
        if 'blast' in P: o['blast_radius'] = P['blast']
        if 'homing' in P: o['homing'] = P['homing']
        wj(f'data/projectiles/{key}.json', o)
    for fid, E in EFFECTS.items():
        wj(f'data/effects/{fid}.json', dict(
            schema_version=1, id=fid, display_name=E['name'],
            sprite=dict(file=f"assets/effects/{E['sprite']}.png", frame_width=E['fw'], frame_height=E['fh'], frame_count=E['frames'], pivot=E['pivot']),
            frame_duration_ms=E['ms'], loop=E['loop']))
    wj('data/salvage/commodities.json', dict(schema_version=1, commodities=[
        dict(id=f'com_{k}', display_name=nm, sprite=sprite_ref('salvage', f'salvage_{k}', 16, 16, dict(x=8, y=8)), mass_per_unit=m)
        for (k, nm, _), m in zip(SALVAGE_ITEMS, (1, 1, 3, 4, 1, 2, 3))]))
    wj('data/salvage/container_generic.json', dict(
        schema_version=1, id='container_generic', display_name='Cargo Container',
        sprite=sprite_ref('salvage', 'salvage_container_generic', 16, 16, dict(x=8, y=8)), collect_radius=14, despawn_after_s=180,
        drift=dict(max_speed=6, max_spin_deg_s=30),
        loot_table=[dict(commodity_id='com_food', min_quantity=1, max_quantity=4, weight=30), dict(commodity_id='com_metal', min_quantity=1, max_quantity=3, weight=25),
                    dict(commodity_id='com_fuel', min_quantity=1, max_quantity=2, weight=20), dict(commodity_id='com_equipment', min_quantity=1, max_quantity=1, weight=15),
                    dict(commodity_id='com_luxury', min_quantity=1, max_quantity=1, weight=10)]))
    wj('data/examples/loadout_player_example.json', dict(
        schema_version=1, ship_instance_id='player_01', hull_id='hull_player_runner',
        installed=[dict(hardpoint_id='hp_wing_l', weapon_id='wpn_laser_cannon'), dict(hardpoint_id='hp_wing_r', weapon_id='wpn_laser_cannon'),
                   dict(hardpoint_id='hp_nose', weapon_id='wpn_pulse_cannon')]))
    wj('data/examples/loadout_pirate_example.json', dict(
        schema_version=1, ship_instance_id='pirate_01', hull_id='hull_pirate_interceptor',
        installed=[dict(hardpoint_id='hp_claw_l', weapon_id='wpn_laser_cannon'), dict(hardpoint_id='hp_claw_r', weapon_id='wpn_laser_cannon')]))
    wj('data/examples/loadout_cargo_example.json', dict(
        schema_version=1, ship_instance_id='npc_hauler_01', hull_id='hull_cargo_hauler',
        installed=[dict(hardpoint_id='hp_nose_turret', weapon_id='wpn_turret_autocannon')]))

def main():
    build_ships(); build_weapons(); build_projectiles(); build_effects()
    build_asteroids(); build_wreckage(); build_station(); build_planets(); build_backgrounds()
    build_salvage(); build_ui(); build_data()
    with open(os.path.join(ROOT, 'tools', 'manifest.json'), 'w') as f: json.dump(MANIFEST, f, indent=1)
    print('assets:', len(MANIFEST))

if __name__ == '__main__':
    main()
