#!/usr/bin/env python3
"""Builds docs/preview_contact_sheet_*.png (review aid only, NOT a game asset)."""
import os, json
from PIL import Image
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
man = json.load(open(os.path.join(ROOT, 'tools', 'manifest.json')))
def sheet(cats, scale, out, maxw=1000, bg=(28, 32, 48, 255)):
    items = [m for m in man if m['category'] in cats and m['category'] != 'backgrounds' or (m['category'] in cats and m['width'] <= 128)]
    x = y = 4; rowh = 0; placed = []
    for m in items:
        im = Image.open(os.path.join(ROOT, m['file'])).convert('RGBA')
        s = scale if im.width * scale < maxw else max(1, maxw // im.width)
        im = im.resize((im.width * s, im.height * s), Image.NEAREST)
        if x + im.width + 4 > maxw: x = 4; y += rowh + 6; rowh = 0
        placed.append((im, x, y)); x += im.width + 6; rowh = max(rowh, im.height)
    canvas = Image.new('RGBA', (maxw, y + rowh + 8), bg)
    for im, px, py in placed: canvas.alpha_composite(im, (px, py))
    canvas.save(os.path.join(ROOT, 'docs', out))
if __name__ == '__main__':
    sheet(['ships'], 4, 'preview_ships.png')
    sheet(['weapons', 'projectiles'], 5, 'preview_weapons.png')
    sheet(['effects'], 3, 'preview_effects.png')
    sheet(['asteroids', 'stations', 'planets', 'salvage', 'backgrounds'], 3, 'preview_env.png')
    sheet(['ui'], 4, 'preview_ui.png')
