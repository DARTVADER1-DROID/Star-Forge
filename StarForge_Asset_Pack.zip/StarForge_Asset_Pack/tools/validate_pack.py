#!/usr/bin/env python3
"""QA for the Star-Forge asset pack. Exit code 1 on any failure. Requires Pillow."""
import os, sys, json, glob, hashlib
from PIL import Image
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
errors, notes = [], []
def err(m): errors.append(m)
def J(rel):
    try:
        with open(os.path.join(ROOT, rel)) as f: return json.load(f)
    except Exception as e:
        err(f'JSON parse failed {rel}: {e}'); return None
SIZES = ['small', 'medium', 'large', 'extra_large']; MOUNTS = ['fixed', 'turret']
PAD = {'small': 4, 'medium': 6, 'large': 8, 'extra_large': 10}

# 1. PNGs
pngs = sorted(glob.glob(os.path.join(ROOT, 'assets', '**', '*.png'), recursive=True))
hashes = {}
for p in pngs:
    rel = os.path.relpath(p, ROOT)
    try:
        im = Image.open(p); im.load(); im = im.convert('RGBA')
    except Exception as e:
        err(f'cannot open {rel}: {e}'); continue
    h = hashlib.sha1(im.tobytes() + str(im.size).encode()).hexdigest()
    if h in hashes: err(f'duplicate image content: {rel} == {hashes[h]}')
    hashes[h] = rel
    px = im.load()
    if 'bg_nebula' in rel:
        if any(px[x, y][3] != 255 for x in range(im.width) for y in range(im.height)): err(f'{rel} should be fully opaque')
    else:
        if px[0, 0][3] != 0 and 'ui_panel' not in rel and 'ui_button_9slice' not in rel and 'ui_joystick_base' not in rel and 'exhaust' not in rel:
            err(f'{rel}: corner pixel not transparent')
        if all(px[x, y][3] > 0 for x in range(im.width) for y in range(im.height)): err(f'{rel}: no transparency at all')
        if all(px[x, y][3] == 0 for x in range(im.width) for y in range(im.height)): err(f'{rel}: fully transparent (empty)')
    # no white/black matte: transparent pixels must not be the only thing; check opaque-edge halos
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = px[x, y]
            if a == 0 and (r, g, b) not in ((0, 0, 0),): err(f'{rel}: transparent pixel with colour data'); break
        else: continue
        break

# 2. manifest vs disk
man = J('tools/manifest.json') or []
for m in man:
    path = os.path.join(ROOT, m['file'])
    if not os.path.exists(path): err(f"manifest file missing {m['file']}"); continue
    im = Image.open(path)
    if im.size != (m['width'], m['height']): err(f"size mismatch {m['file']}")
    if im.width != m['frame_w'] * m['frames'] or im.height != m['frame_h']: err(f"frame geometry mismatch {m['file']}")
    if m['frames_dir']:
        for i in range(m['frames']):
            fp = os.path.join(ROOT, m['frames_dir'], f"{os.path.basename(m['file'])[:-4]}_{i:02d}.png")
            if not os.path.exists(fp): err(f'missing frame {fp}')
            elif Image.open(fp).size != (m['frame_w'], m['frame_h']): err(f'frame size mismatch {fp}')
mfiles = {m['file'] for m in man}
frames_dirs = [m['frames_dir'] for m in man if m['frames_dir']]
for p in pngs:
    rel = os.path.relpath(p, ROOT).replace(os.sep, '/')
    if rel not in mfiles and not any(rel.startswith(d + '/') for d in frames_dirs): err(f'PNG not in manifest: {rel}')

# 3. JSON
ids = {k: {} for k in ('hull', 'weapon', 'projectile', 'effect', 'commodity')}
def sprite_ok(owner, s, frames=None):
    f = os.path.join(ROOT, s['file'])
    if not os.path.exists(f): err(f'{owner}: sprite missing {s["file"]}'); return None
    im = Image.open(f)
    if frames:
        if im.size != (s['frame_width'] * s['frame_count'], s['frame_height']): err(f'{owner}: frame geometry != PNG size')
    elif im.size != (s['width'], s['height']): err(f'{owner}: declared {s["width"]}x{s["height"]} but PNG is {im.size}')
    pv = s.get('pivot')
    if pv:
        fw, fh = (s['frame_width'], s['frame_height']) if frames else im.size
        if not (0 <= pv['x'] <= fw and 0 <= pv['y'] <= fh): err(f'{owner}: pivot outside sprite')
    return im
for sub in ('ships', 'weapons', 'projectiles', 'effects'):
    for f in sorted(glob.glob(os.path.join(ROOT, 'data', sub, '*.json'))):
        d = J(os.path.relpath(f, ROOT))
        if not d: continue
        kind = {'ships': 'hull', 'weapons': 'weapon', 'projectiles': 'projectile', 'effects': 'effect'}[sub]
        if d['id'] in ids[kind]: err(f'duplicate {kind} id {d["id"]}')
        ids[kind][d['id']] = d
for hid, h in ids['hull'].items():
    im = sprite_ok(hid, h['sprite']); 
    if im is None: continue
    im = im.convert('RGBA'); w, hh = im.size; seen = set()
    for hp in h['hardpoints']:
        if hp['id'] in seen: err(f'{hid}: duplicate hardpoint {hp["id"]}')
        seen.add(hp['id'])
        if hp['max_size'] not in SIZES or hp['mount_type'] not in MOUNTS: err(f'{hid}.{hp["id"]}: bad enum')
        s = PAD[hp['max_size']]; px, py = w // 2 + hp['position']['x'], hh // 2 + hp['position']['y']
        for yy in range(py - s // 2, py + s // 2):
            for xx in range(px - s // 2, px + s // 2):
                if not (0 <= xx < w and 0 <= yy < hh and im.getpixel((xx, yy))[3] > 0): err(f'{hid}.{hp["id"]}: mount pad leaves hull silhouette at ({xx},{yy})'); break
            else: continue
            break
    for e in h['exhaust_points']:
        if e['effect_id'] not in ids['effect']: err(f'{hid}: unknown effect {e["effect_id"]}')
for wid, wp in ids['weapon'].items():
    sprite_ok(wid, wp['sprite'])
    if wp['size'] not in SIZES or wp['mount_type'] not in MOUNTS: err(f'{wid}: bad enum')
    if wp['projectile_id'] not in ids['projectile']: err(f'{wid}: unknown projectile')
    if wp['muzzle']['flash_effect_id'] not in ids['effect']: err(f'{wid}: unknown flash effect')
for pid, p in ids['projectile'].items():
    sprite_ok(pid, p['sprite'])
    if p['impact_effect_id'] not in ids['effect']: err(f'{pid}: unknown impact effect')
for eid, e in ids['effect'].items(): sprite_ok(eid, e['sprite'], frames=True)
com = J('data/salvage/commodities.json') or {'commodities': []}
for c in com['commodities']: sprite_ok(c['id'], c['sprite']); ids['commodity'][c['id']] = c
cont = J('data/salvage/container_generic.json')
if cont:
    sprite_ok('container', cont['sprite'])
    for l in cont['loot_table']:
        if l['commodity_id'] not in ids['commodity']: err(f'container: unknown commodity {l["commodity_id"]}')
for f in sorted(glob.glob(os.path.join(ROOT, 'data', 'examples', '*.json'))):
    d = J(os.path.relpath(f, ROOT))
    if d and 'installed' in d:
        hull = ids['hull'].get(d['hull_id'])
        if not hull: err(f'{f}: unknown hull'); continue
        hps = {h['id']: h for h in hull['hardpoints']}; mass = 0; power = 0
        for i in d['installed']:
            w = ids['weapon'].get(i['weapon_id']); h = hps.get(i['hardpoint_id'])
            if not w or not h: err(f'{f}: bad reference {i}'); continue
            if SIZES.index(w['size']) > SIZES.index(h['max_size']): err(f'{f}: {w["id"]} too big for {h["id"]}')
            if w['mount_type'] != h['mount_type']: err(f'{f}: mount mismatch {w["id"]}/{h["id"]}')
            mass += w['mass']; power += w['power_draw']
        st = hull['stats']
        if mass > st['equipment_mass_capacity']: err(f'{f}: mass {mass} > {st["equipment_mass_capacity"]}')
        if power > st['power_output']: err(f'{f}: power {power} > {st["power_output"]}')
        notes.append(f'{os.path.basename(f)}: mass {mass}/{st["equipment_mass_capacity"]}, power {power}/{st["power_output"]}')

# 4. docs / licences
for d in ('ART_STYLE_GUIDE', 'ASSET_CATALOG', 'ASSET_INTEGRATION', 'SPRITE_COORDINATES', 'SHIP_LAYOUT_SPEC', 'WEAPON_MOUNTING_SPEC', 'WEAPON_DATA_SCHEMA', 'ANIMATION_SPEC', 'LICENSES'):
    if not os.path.exists(os.path.join(ROOT, 'docs', d + '.md')): err(f'missing doc {d}.md')
for f in ('README.md', 'LICENSES/README.md'):
    if not os.path.exists(os.path.join(ROOT, f)): err(f'missing {f}')
print(f'PNG files checked: {len(pngs)}   manifest entries: {len(man)}')
print(f"hulls {len(ids['hull'])}, weapons {len(ids['weapon'])}, projectiles {len(ids['projectile'])}, effects {len(ids['effect'])}, commodities {len(ids['commodity'])}")
for n in notes: print('  loadout', n)
if errors:
    print(f'\n{len(errors)} PROBLEM(S):'); [print(' -', e) for e in errors]; sys.exit(1)
print('\nALL CHECKS PASSED')
