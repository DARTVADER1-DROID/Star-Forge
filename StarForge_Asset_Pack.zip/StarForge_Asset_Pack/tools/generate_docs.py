#!/usr/bin/env python3
"""Generates docs/*.md tables from the real files on disk (so numbers cannot drift). Run after generate_assets.py."""
import os, sys, json, glob
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import generate_assets as G
from PIL import Image
ROOT = G.ROOT
man = json.load(open(os.path.join(ROOT, 'tools', 'manifest.json')))
def W(name, text):
    with open(os.path.join(ROOT, 'docs', name), 'w') as f: f.write(text.strip() + '\n')
def hexc(c): return '#%02x%02x%02x' % c[:3]
def piv(m): return f"({m['pivot']['x']},{m['pivot']['y']})" if m.get('pivot') else '-'
def D(rel): return json.load(open(os.path.join(ROOT, rel)))
def jdump(rel): return '```json\n' + open(os.path.join(ROOT, rel)).read().strip() + '\n```'
ships = {k: D(f'data/ships/{k}.json') for k in G.SHIPS}
weapons = {k: D(f'data/weapons/{k}.json') for k in G.WEAPONS}
effects = {f: D(f'data/effects/{f}.json') for f in G.EFFECTS}

# ---------------- ART STYLE GUIDE ----------------
def palrow(name, p): return f"| {name} | " + ' | '.join(f"`{hexc(p[k])}`" for k in ('d', 's', 'm', 'l', 'h')) + ' |'
W('ART_STYLE_GUIDE.md', f"""
# Star-Forge Art Style Guide

All art in this pack is original, drawn procedurally by `tools/generate_assets.py` in one consistent style.

## 1. Resolution and scaling
- Internal game resolution: **320x180** (16:9). One art pixel = one internal pixel.
- Scale to the screen with an **integer factor** (`floor(min(screenW/320, screenH/180))`). 1080p landscape = 6x, 720p = 4x. On 20:9 phones either letterbox, or (preferred) widen the visible world horizontally (e.g. 360x162 or 400x180 viewport) rather than stretching.
- Always use **nearest-neighbour** texture filtering. Never use linear filtering or mipmaps.

## 2. Sprite sizes (all dimensions are exact, see ASSET_CATALOG.md)
| Group | Sizes used |
|---|---|
| Small ships (runner class) | 32x32 |
| Medium ships (corvette class) | 48x48 |
| Destroyer | 64x64 |
| Frigate | 96x96 |
| Weapons | 16x16, 24x24, 24x40 (railgun) |
| Projectiles | 4x12, 8x8, 8x12, 4x24, 8x16 |
| Asteroids | 16, 24, 32, 48 square |
| Pickups / UI icons | 16x16 (large container 24x24) |
| Planets / station | 32, 64, 96 square |

Ship, weapon and effect sprites have **even** dimensions so the pivot (the sprite centre) lies on a pixel edge and mirrored art is exactly symmetric.

## 3. Outline
- Every object has a **1 px dark outline**, colour `{hexc(G.OUT)}` (same for all factions), drawn *inside* the silhouette so the PNG size equals the visible size.
- Effects (flames, flashes, explosions, projectiles) are glow-style and have **no outline**.

## 4. Shading
- Light comes from the **top-left**. Four tones per material: dark (`d`), shadow-mid (`s`), mid (`m`), light (`l`), plus highlight (`h`).
- Rim rule: pixels touching the outline on the top/left side use the light tone; bottom/right side use the dark tone. Right-hand interior is shadow-mid, left-hand interior mid.
- A 2 px light centre ridge runs down symmetric hulls.
- **No anti-aliasing, no gradients, no semi-transparent edges** (exceptions: virtual joystick base, orbit ring, rail slug tail and star-point halos, which use deliberate alpha).

## 5. Orientation
- Top-down view. Every ship, weapon, projectile, flash and exhaust sprite is authored **facing up (north)**. Exhaust flames point down.
- Rotation is applied at runtime (see SPRITE_COORDINATES.md). Never bake rotation into art.

## 6. Faction colour coding (readability at small sizes)
| Role | Hue | Palette (dark, shadow-mid, mid, light, highlight) |
|---|---|---|
{palrow('Player', G.PLAYER)}
{palrow('Civilian', G.CIVIL)}
{palrow('Cargo', G.CARGO)}
{palrow('Pirate', G.PIRATE)}
{palrow('Military', G.MILITARY)}

Silhouette cues: player = compact arrowhead with swept wings; pirate = spiky forward-swept claws; cargo = long spine flanked by coloured containers; civilian = smooth rounded fuselage with lit windows; military = broad armoured grey hull with panel lines and amber lights.

## 7. Hardpoint pads
Weapons are never painted on hulls. Each hardpoint is marked by a recessed square pad (`{hexc(G.PAD_D)}` / `{hexc(G.PAD_M)}` concentric rings). Pad edge length by size class: small 4, medium 6, large 8, extra-large 10 px. Pads are centred exactly on the hardpoint coordinates in `data/ships/*.json`.

## 8. Effects palette
Heat ramp (explosions, flashes, fire): `#fffbe0 #ffe36e #ff9a2e #d7351f #7a1d1a`. Energy ramp: `#ffffff #bff4ff #5cd4ff #2457b0`. Smoke: `#3a3a44 ... #a0a0aa`. Exhaust colour per faction: blue (player/civilian/military), orange (cargo), red (pirate).

## 9. Consistency rules for new art
1. Same outline colour, same light direction, <=5 tones per material.
2. Keep the 320x180 test in mind: a ship must be identifiable by silhouette + dominant colour at 1x.
3. Even dimensions for anything that rotates around its centre.
4. No text baked into game objects.
5. Transparent background, no matte colour in fully transparent pixels.
6. Weapons/turrets are never part of a hull PNG.
7. Preview sheets in `docs/preview_*.png` are review aids only, not game assets.
""")

# ---------------- ASSET CATALOG ----------------
cats = ['ships', 'weapons', 'projectiles', 'effects', 'asteroids', 'stations', 'planets', 'salvage', 'ui', 'backgrounds']
intro = {'asteroids': 'Rocks plus wreckage debris (`wreckage_*`). Wreckage lives here because the required folder list has no separate wreckage folder.',
         'effects': 'Horizontal strips; frames are equal-sized, left to right. Individual frames are in `assets/effects/frames/<name>/<name>_NN.png`. See ANIMATION_SPEC.md.',
         'ui': 'Inventory item icons are the 16x16 `salvage_*` sprites (same art reused, no duplicate files). Nine-slice margins are in SPRITE_COORDINATES.md.',
         'backgrounds': 'Star layers are 128x128 transparent tiles. `bg_nebula_320x180.png` is the only opaque image in the pack.'}
t = ['# Asset Catalog', '', f'Total sprite/sheet files: **{len(man)}** (plus individual animation frames). Generated from the files on disk. Pivot is in sprite pixels from the top-left of one frame (see SPRITE_COORDINATES.md).', '']
for c in cats:
    rows = [m for m in man if m['category'] == c]
    t += [f'## {c} ({len(rows)})', '', intro.get(c, ''), '', '| File | Size | Frames | Pivot | Intended use |', '|---|---|---|---|---|']
    for m in rows:
        fr = f"{m['frames']} x {m['frame_w']}x{m['frame_h']}" if m['frames'] > 1 else '1'
        t.append(f"| `{m['file']}` | {m['width']}x{m['height']} | {fr} | {piv(m)} | {m['use']} |")
    t.append('')
t += ['## Data files', '', '| Folder | Files |', '|---|---|']
for sub in ('ships', 'weapons', 'projectiles', 'effects', 'salvage', 'examples'):
    t.append(f"| `data/{sub}/` | " + ', '.join(f"`{os.path.basename(p)}`" for p in sorted(glob.glob(os.path.join(ROOT, 'data', sub, '*.json')))) + ' |')
t += ['', '## Hull summary', '', '| Hull id | Class / configuration | Faction | Sprite | Hardpoints |', '|---|---|---|---|---|']
for k, s in ships.items():
    t.append(f"| `{s['id']}` | {s['hull_class']} / {s['configuration']} | {s['faction']} | `{s['sprite']['file']}` {s['sprite']['width']}x{s['sprite']['height']} | {len(s['hardpoints'])} |")
t += ['', '## Not included (see README "Gaps")', '', 'Battleship and Flagship hulls; configuration variants of the same hull (e.g. a military Runner); NPC faction recolours; planet surface close-ups; shields; sound.']
W('ASSET_CATALOG.md', '\n'.join(t))
with open(os.path.join(ROOT, 'docs', 'asset_inventory.csv'), 'w') as f:
    f.write('category,file,width,height,frames,frame_w,frame_h,pivot_x,pivot_y,use\n')
    for m in man:
        p = m.get('pivot') or {}
        f.write(f"{m['category']},{m['file']},{m['width']},{m['height']},{m['frames']},{m['frame_w']},{m['frame_h']},{p.get('x','')},{p.get('y','')},\"{m['use']}\"\n")

# ---------------- ANIMATION SPEC ----------------
t = ["""# Animation Specification

## Frame layout
- Every animation is a **single horizontal strip**: frame `i` occupies `x = i * frame_width`, `y = 0`, size `frame_width x frame_height`. All frames in a strip have identical dimensions.
- Frame order is playback order (0 first). Individual frames are also provided as `assets/effects/frames/<sprite>/<sprite>_NN.png` (NN zero-padded) for debugging.
- Timing is `frame_duration_ms` per frame (constant). `loop: true` wraps to frame 0; `loop: false` plays once and the effect instance is removed after the last frame has been shown for its full duration.
- Pivot is in frame-local pixels from the frame's top-left; the pivot is the point placed at the effect's world position.

## Effect table (generated from data/effects/*.json)
| Effect id | Sheet | Frame | Frames | ms/frame | fps | Total ms | Loop | Pivot | Anchor semantics |
|---|---|---|---|---|---|---|---|---|---|"""]
anchor = {'exhaust': 'top-centre: place at hull `exhaust_points`, draw BEHIND hull, flame points down (ship-local +Y)', 'muzzle': 'bottom-centre of flash = weapon muzzle; rotate with weapon', 'explosion': 'centre', 'damage': 'bottom-centre: place on hull'}
for fid, e in effects.items():
    s = e['sprite']; a = next(v for k, v in anchor.items() if k in fid)
    t.append(f"| `{fid}` | `{s['file']}` | {s['frame_width']}x{s['frame_height']} | {s['frame_count']} | {e['frame_duration_ms']} | {1000 / e['frame_duration_ms']:.1f} | {e['frame_duration_ms'] * s['frame_count']} | {str(e['loop']).lower()} | ({s['pivot']['x']},{s['pivot']['y']}) | {a} |")
t.append("""
## Playback rules
1. **Exhaust** (looping): start when thrust > 0, stop (or fade out by skipping draw) when thrust = 0. Boost may draw it at 1.5x scale (integer-rounded) or use the `exhaust_large_blue` sheet. Give each instance a random start frame so engines do not pulse in unison.
2. **Muzzle flash** (one-shot, 3 frames x 40 ms): spawn when a weapon fires at `weapon pivot + rotate(muzzle.offset)`, rotated to the weapon's world angle.
3. **Explosion** (one-shot, 8 frames x 70 ms = 560 ms): spawn on projectile impact or ship death. Use `fx_explosion_large` for hulls of 48 px and above and for missiles. Chaining several small explosions at random hull points before the large one is recommended for frigates.
4. **Damage smoke / fire** (looping): suggestion only - smoke below 50% health, fire below 25%, anchored at a fixed random point inside the hull. Thresholds are gameplay tuning, not asset data.
5. Draw order (back to front): background layers, planets/stations, asteroids/wreckage/pickups, exhaust, ship hulls, weapons, projectiles, damage effects, explosions/flashes, UI.

## Reference update code (C17)
```c
typedef struct { const SfAnimDef *def; float t_ms; bool done; } SfAnimInst;

static void sf_anim_update(SfAnimInst *a, float dt_ms) {
    if (a->done) return;
    a->t_ms += dt_ms;
    float total = (float)(a->def->frame_duration_ms * a->def->frame_count);
    if (a->t_ms >= total) {
        if (a->def->loop) a->t_ms = fmodf(a->t_ms, total);
        else { a->t_ms = total - 0.001f; a->done = true; }
    }
}
static int sf_anim_frame(const SfAnimInst *a) {
    return (int)(a->t_ms / (float)a->def->frame_duration_ms);   /* 0 .. frame_count-1 */
}
/* source rect: { frame * frame_width, 0, frame_width, frame_height } */
```
""")
W('ANIMATION_SPEC.md', '\n'.join(t))

# ---------------- SPRITE COORDINATES ----------------
t = ["""# Sprite Coordinates, Pivots, Scaling and Rotation

## Conventions
- **Sprite-local space**: origin at the sprite's **top-left corner**, +X right, +Y down, units = art pixels. Pixel `(0,0)` covers the area `[0,1)x[0,1)`.
- **Ship-local space**: origin at the ship sprite's **pivot**; same axes. The pivot of every hull is its geometric centre `(width/2, height/2)`, a point on a pixel *edge* (hulls have even dimensions). A hardpoint at `(x,y)` is therefore at sprite pixel position `(width/2 + x, height/2 + y)`.
- **Forward** is up: ship-local `(0,-1)`. Heading angle 0 = north; positive angles rotate **clockwise** on screen (matches SDL's `angle` parameter, which is in degrees).
- All coordinates in JSON are integers in internal 320x180 pixels, never screen pixels.

## Transforms
Rotate a ship-local vector `(x,y)` by heading `h` (radians, clockwise, y-down):
```c
float c = cosf(h), s = sinf(h);
float wx = ship.x + (x * c - y * s);
float wy = ship.y + (x * s + y * c);
/* forward unit vector for heading h: (sin h, -cos h)   e.g. h = 90deg -> (1, 0) = east */
```
Weapon world angle = `ship.heading + hardpoint.orientation_offset_deg (+ turret aim offset within the arc)`.
Muzzle world position = weapon world position + rotate(muzzle.offset, weapon world angle). `muzzle.offset` is relative to the weapon sprite pivot; forward is negative Y.

## Drawing with SDL3
```c
/* ship sprite centred on world position, rotated about its pivot */
SDL_FRect dst = { (ship.x - cam.x) * scale - pivot.x * scale,
                  (ship.y - cam.y) * scale - pivot.y * scale,
                  spr.w * scale, spr.h * scale };
SDL_FPoint center = { pivot.x * scale, pivot.y * scale };   /* relative to dst top-left */
SDL_RenderTextureRotated(r, tex, NULL, &dst, heading_deg, &center, SDL_FLIP_NONE);
```
With `SDL_SetRenderLogicalPresentation(r, 320, 180, SDL_LOGICAL_PRESENTATION_INTEGER_SCALE)` SDL applies the integer scale for you, so use `scale = 1`.
Rotated pixel art looks coarse at arbitrary angles; this is accepted. If it bothers you later, pre-render 32 rotations per hull at load time with nearest sampling - not needed for the first integration.
Snap sprite destination positions to whole internal pixels (`floorf`) when the ship is not rotating to avoid shimmer.

## Scaling
Integer scale only (see ART_STYLE_GUIDE.md). Never scale sprites individually by fractional factors. UI uses the same internal space; touch targets: the 32 px buttons become 192 px at 6x, comfortably above 48 dp on typical phones.

## Pivot table (generated)
| Asset | Size | Pivot | Notes |
|---|---|---|---|"""]
for m in man:
    if m['pivot'] and m['category'] in ('ships', 'weapons', 'projectiles', 'effects', 'ui', 'salvage'):
        t.append(f"| `{os.path.basename(m['file'])}` | {m['frame_w']}x{m['frame_h']} | {piv(m)} | {m['category']} |")
t.append("""
Asteroids, planets, stations, wreckage: pivot = centre. Backgrounds have no pivot (tile/scroll them).

## Nine-slice UI
| File | Size | Margins L/T/R/B | Stretch |
|---|---|---|---|
| `ui_panel_9slice.png` | 24x24 | 6/6/6/6 | centre and edges |
| `ui_button_9slice_normal.png` / `_pressed` / `_disabled` | 24x24 | 6/6/6/6 | centre and edges |

`SDL_RenderTexture9Grid(r, tex, NULL, 6, 6, 6, 6, 1.0f, &dst);` Use integer destination sizes. Corner pixels are transparent to give rounded corners.

## Weapon sprite pivots
A weapon pivot is the **mount rotation axis**: place it exactly on the hardpoint position. Fixed weapons point along the hardpoint's orientation; turrets rotate about the pivot.

## Parallax star tiles
`stars_*_128.png` tile seamlessly (no star within 2 px of an edge). Draw a grid of tiles offset by `-fmodf(cam.x * factor, 128)`; suggested factors far 0.1, mid 0.25, near 0.5. Stars never wrap across a tile edge, so there are no seams.
""")
W('SPRITE_COORDINATES.md', '\n'.join(t))

# ---------------- SHIP LAYOUT SPEC ----------------
def ascii_layout(s):
    w = s['sprite']['width']; g = 2 if w <= 48 else 4; n = w // g
    grid = [['.'] * n for _ in range(n)]
    for hp in s['hardpoints']:
        gx, gy = (w // 2 + hp['position']['x']) // g, (w // 2 + hp['position']['y']) // g
        grid[min(gy, n - 1)][min(gx, n - 1)] = {'small': 'S', 'medium': 'M', 'large': 'L', 'extra_large': 'X'}[hp['max_size']]
    for e in s['exhaust_points']:
        gx, gy = (w // 2 + e['position']['x']) // g, (w // 2 + e['position']['y']) // g
        grid[min(gy, n - 1)][min(gx, n - 1)] = 'v'
    return '\n'.join(''.join(r) for r in grid)
t = ["""# Ship Layout Specification

A **hull** (`data/ships/*.json`) describes the ship itself and its **hardpoints**: empty, typed mounting slots. A hull never says which weapon is installed. Installed weapons live in a separate **loadout** (`data/examples/loadout_*.json`). Weapon behaviour lives in `data/weapons/*.json` (see WEAPON_DATA_SCHEMA.md); compatibility rules are in WEAPON_MOUNTING_SPEC.md.

## Coordinate convention
- Sprite-local: origin top-left, +X right, +Y down.
- Ship faces **up** by default. Forward is `-Y`.
- Hardpoint and exhaust coordinates are **ship-local pixels relative to the sprite pivot** (the sprite centre, `pivot = (width/2, height/2)`), not relative to the top-left. Left of the pivot is negative X, ahead of the pivot is negative Y.
- Sprite pixel = `(pivot.x + x, pivot.y + y)`. The mount pad art occupies `[px - size/2, px + size/2)` on both axes, where size is 4/6/8/10 px for small/medium/large/extra_large.

## Hull file fields (`data/ships/<name>.json`)
| Field | Type | Meaning |
|---|---|---|
| `schema_version` | int | Always 1. |
| `id` | string | Unique hull id, referenced by loadouts. |
| `display_name` | string | Name shown to the player. |
| `hull_class` | enum | `runner`, `destroyer`, `corvette`, `frigate`, `battleship`, `flagship`. Only the first four have art in this pack. |
| `configuration` | enum | `civilian`, `cargo`, `military`. |
| `faction` | string | `player`, `civilian`, `pirate`, `military`. Free-form tag used by AI/colouring. |
| `sprite.file/width/height` | string/int/int | PNG path relative to the pack root and its exact pixel size. |
| `sprite.pivot.x/y` | int | Rotation/position origin in sprite pixels. |
| `stats.max_health` | number | Hull points. |
| `stats.mass_empty` | number | Hull mass without equipment (units: mass units, mu). Used for acceleration, not for the equipment check. |
| `stats.equipment_mass_capacity` | number | Maximum total mass of installed equipment (mu). |
| `stats.power_output` | number | Power units the reactor supplies. |
| `stats.cargo_capacity` | number | Total cargo mass the hold can carry (mu, same unit as commodity `mass_per_unit`). |
| `stats.fuel_capacity` | number | Fuel units. |
| `stats.thrust` | number | Acceleration in px/s^2. |
| `stats.max_speed` | number | px/s. |
| `stats.turn_rate_deg_s` | number | Degrees per second. |
| `exhaust_points[]` | array | Where engine flames attach: `id`, `position{x,y}` (ship-local), `effect_id` (see data/effects). |
| `hardpoints[]` | array | See below. |

All stat numbers are **starting placeholders** for tuning; they are consistent with each other (the example loadouts pass all checks) but are not balanced.

## Hardpoint fields
| Field | Type | Meaning |
|---|---|---|
| `id` | string | Unique within the hull. |
| `position.x/y` | int | Ship-local pixels relative to the pivot. |
| `max_size` | enum | Largest weapon size the mount accepts: `small` < `medium` < `large` < `extra_large`. Smaller weapons also fit. |
| `mount_type` | enum | `fixed` (weapon fires along the mount's axis) or `turret` (weapon may rotate inside `arc_deg`). A weapon fits only when its `mount_type` is equal. |
| `orientation_offset_deg` | number | Direction of the mount's centre line relative to ship forward, clockwise positive. 0 = forward, 90 = right, 180 = rear. |
| `arc_deg` | number | Total firing arc width centred on the orientation. Must be 0 for `fixed` mounts, 1-360 for `turret` mounts. |
| `restrictions` | object, optional | `allowed_tags`: weapon must have at least one of these tags. `blocked_tags`: weapon must have none. Omit for no restriction. |

## Loadout file fields (`data/examples/loadout_*.json`)
`schema_version`, `ship_instance_id` (runtime instance name), `hull_id`, `installed[]` of `{hardpoint_id, weapon_id}`. A hardpoint may appear at most once; unlisted hardpoints are empty.

## Hardpoint layouts per hull
Legend: S/M/L/X = small/medium/large/extra-large hardpoint, `v` = exhaust point. One character is 2 px for hulls up to 48 px wide and 4 px for the 64 px and 96 px hulls.
"""]
for k, s in ships.items():
    t += [f"### `{s['id']}` - {s['display_name']} ({s['hull_class']}/{s['configuration']}, {s['sprite']['width']}x{s['sprite']['height']})", '', '```', ascii_layout(s), '```', '',
          '| Hardpoint | x,y | max size | mount | offset deg | arc deg | restrictions |', '|---|---|---|---|---|---|---|']
    for hp in s['hardpoints']:
        t.append(f"| `{hp['id']}` | {hp['position']['x']},{hp['position']['y']} | {hp['max_size']} | {hp['mount_type']} | {hp['orientation_offset_deg']} | {hp['arc_deg']} | {json.dumps(hp.get('restrictions', '-'))} |")
    t.append('')
t += ["""## Layout archetypes (why the examples differ)
1. **Runner (player)** - three forward-firing fixed guns (two small wing guns, one medium nose gun): high alpha strike, no coverage behind.
2. **Pirate interceptor** - two small wing-tip fixed guns only: glass cannon.
3. **Cargo hauler** - two small turrets, front and rear, wide arcs: pure self-defence.
4. **Civilian transport** - a single small dorsal turret.
5. **Destroyer** - twin medium nose guns, two large wing guns, one medium dorsal turret.
6. **Frigate** - one extra-large spinal mount (restricted to `spinal` weapons), two large bow guns, four medium turrets, two small point-defence turrets with 360 degree arcs.

## Adding a hull
1. Draw a sprite with an even size, outline and mount pads per ART_STYLE_GUIDE.md.
2. Write the JSON; every pad must sit fully on opaque hull pixels (`tools/validate_pack.py` checks this).
3. Mirror left/right hardpoints (`-x`/`+x`) and negate `orientation_offset_deg` on the left.

## Unresolved design decision: fusion
A weapon **fusion mechanic** (combining weapons) is intentionally **not specified or implemented**. Its behaviour is undecided: it is unknown whether fusion consumes hardpoints, combines mass/power, changes size class, produces new weapon ids, or is reversible. **No fields, enums or code paths for fusion exist in this pack.** When the design is settled, extend the weapon schema (e.g. a new weapon definition kind) without changing hull files; hardpoints are already independent of installed weapons.
"""]
W('SHIP_LAYOUT_SPEC.md', '\n'.join(t))

# ---------------- WEAPON MOUNTING SPEC ----------------
pl = D('data/examples/loadout_player_example.json'); ph = ships['ship_player_runner']
W('WEAPON_MOUNTING_SPEC.md', """
# Weapon Mounting Specification

Hardpoint compatibility and equipment mass/power are **separate checks**. A weapon can be perfectly compatible with a hardpoint and still be rejected because the ship has no spare mass or power, and the opposite is also true. Report them as distinct failure reasons.

## Vocabulary
- **Size classes** (ordered): `small`=0, `medium`=1, `large`=2, `extra_large`=3.
- **Mount types**: `fixed`, `turret`.
- **Equipment mass**: sum of `mass` of installed weapons (and, later, other equipment). Limited by `stats.equipment_mass_capacity`. It is unrelated to hull `mass_empty` and unrelated to how many hardpoints exist.
- **Power**: sum of `power_draw` of installed weapons, limited by `stats.power_output`. (`energy_per_shot` is a separate runtime drain from the ship's energy pool and is not part of installation checks.)

## Install algorithm
Input: hull, current loadout, `hardpoint_id`, `weapon_id`. Run the checks **in this order** and stop at the first failure:

| # | Check | Rule | Error |
|---|---|---|---|
| 1 | Compatible hardpoint exists | the hull has a hardpoint with that `id` (when auto-placing: at least one free hardpoint passes checks 2-4) | `NO_SUCH_HARDPOINT` / `NO_COMPATIBLE_HARDPOINT` |
| 2 | Size supported | `size_rank(weapon.size) <= size_rank(hardpoint.max_size)` | `SIZE_TOO_LARGE` |
| 3 | Mount type compatible | `weapon.mount_type == hardpoint.mount_type` | `MOUNT_MISMATCH` |
| 3b | Restrictions | if `allowed_tags` present: weapon shares >= 1 tag; if `blocked_tags` present: weapon shares none | `RESTRICTED` |
| 4 | Equipment mass | `used_mass - replaced_mass + weapon.mass <= stats.equipment_mass_capacity` | `OVER_MASS` |
| 5 | Power | `used_power - replaced_power + weapon.power_draw <= stats.power_output` | `OVER_POWER` |

`replaced_*` is the mass/power of the weapon currently in that hardpoint (0 if empty), so swapping is evaluated as a replacement. Checks 1-3b are **geometry/compatibility**; 4-5 are **resource budget**. The install is atomic: either every check passes and the loadout changes, or nothing changes.

Firing arc: for `fixed` mounts the weapon points along `orientation_offset_deg` (arc 0). For `turret` mounts the aim direction is clamped to `orientation_offset_deg +/- arc_deg/2`; `arc_deg = 360` means unrestricted. The turret's rotation speed is the weapon's `turret_turn_rate_deg_s`.

## Reference implementation (C17)
```c
typedef enum { SF_SIZE_SMALL, SF_SIZE_MEDIUM, SF_SIZE_LARGE, SF_SIZE_XL } SfSize;
typedef enum { SF_MOUNT_FIXED, SF_MOUNT_TURRET } SfMount;
typedef enum { SF_OK, SF_NO_SUCH_HARDPOINT, SF_SIZE_TOO_LARGE, SF_MOUNT_MISMATCH,
               SF_RESTRICTED, SF_OVER_MASS, SF_OVER_POWER } SfInstallResult;

typedef struct { const char *id; int x, y; SfSize max_size; SfMount mount;
                 float offset_deg, arc_deg;
                 const char **allowed_tags; int n_allowed;
                 const char **blocked_tags; int n_blocked; } SfHardpoint;
typedef struct { const char *id; SfSize size; SfMount mount; float mass, power_draw;
                 const char **tags; int n_tags; } SfWeaponDef;

static bool sf_has_tag(const SfWeaponDef *w, const char *t) {
    for (int i = 0; i < w->n_tags; i++) if (strcmp(w->tags[i], t) == 0) return true;
    return false;
}

SfInstallResult sf_can_install(const SfHull *hull, const SfLoadout *lo,
                               int hp_index, const SfWeaponDef *w)
{
    if (hp_index < 0 || hp_index >= hull->n_hardpoints) return SF_NO_SUCH_HARDPOINT;
    const SfHardpoint *hp = &hull->hardpoints[hp_index];

    /* --- compatibility checks (independent of resources) --- */
    if (w->size > hp->max_size)  return SF_SIZE_TOO_LARGE;
    if (w->mount != hp->mount)   return SF_MOUNT_MISMATCH;
    if (hp->n_allowed) {
        bool any = false;
        for (int i = 0; i < hp->n_allowed; i++) any |= sf_has_tag(w, hp->allowed_tags[i]);
        if (!any) return SF_RESTRICTED;
    }
    for (int i = 0; i < hp->n_blocked; i++) if (sf_has_tag(w, hp->blocked_tags[i])) return SF_RESTRICTED;

    /* --- resource checks (independent of hardpoint geometry) --- */
    const SfWeaponDef *old = lo->installed[hp_index];          /* NULL if empty */
    float mass  = sf_loadout_mass(lo)  - (old ? old->mass : 0)       + w->mass;
    float power = sf_loadout_power(lo) - (old ? old->power_draw : 0) + w->power_draw;
    if (mass  > hull->equipment_mass_capacity) return SF_OVER_MASS;
    if (power > hull->power_output)            return SF_OVER_POWER;
    return SF_OK;
}
```

## Worked example (`loadout_player_example.json`)
Hull `hull_player_runner`: equipment mass capacity %s, power output %s.
| Step | Weapon | Hardpoint | Compatibility | Mass after | Power after |
|---|---|---|---|---|---|
| 1 | laser cannon (small, fixed, 4 mu, 3 pu) | `hp_wing_l` small fixed | OK | 4 / 24 | 3 / 14 |
| 2 | laser cannon | `hp_wing_r` | OK | 8 / 24 | 6 / 14 |
| 3 | pulse cannon (medium, fixed, 8 mu, 6 pu) | `hp_nose` medium fixed | OK | 16 / 24 | 12 / 14 |
| - | heavy cannon (large) | `hp_nose` | `SIZE_TOO_LARGE` (compatibility, before mass is even considered) | - | - |
| 4 | missile launcher (medium, fixed, 12 mu, 3 pu) replacing the pulse cannon | `hp_nose` | OK (replacement: 16 - 8 + 12) | 20 / 24 | 9 / 14 |
| - | railgun (extra_large) | `hp_nose` | `SIZE_TOO_LARGE` | - | - |
| - | any weapon pushing totals above 24 mu / 14 pu | any compatible mount | `OVER_MASS` / `OVER_POWER` (resource check, only reached after compatibility passed) | - | - |
| - | turret autocannon (small, turret) | `hp_wing_l` | `MOUNT_MISMATCH` | - | - |

## Runtime firing (informative)
Per weapon: cooldown `1 / fire_rate` s; each shot costs `energy_per_shot` from the ship energy pool; spawn `projectile_id` at the muzzle with speed `projectile_speed` along the weapon's world angle (plus random `spread_deg`); despawn when travelled distance exceeds `range`; apply `damage` of `damage_type` on hit within the projectile's `hit_radius`; explosive projectiles also apply damage within `blast_radius`.

## Unresolved design decision: fusion
Not specified, not implemented, no schema fields. See SHIP_LAYOUT_SPEC.md. Do not add a fusion code path until the design is decided.
""" % (ph['stats']['equipment_mass_capacity'], ph['stats']['power_output']))

# ---------------- WEAPON DATA SCHEMA ----------------
t = ["""# Weapon, Projectile and Related Data Schema

All JSON is UTF-8, `schema_version: 1`. Paths are relative to the pack root. **Units**: distances in internal pixels (320x180 space), speeds in px/s, time in seconds unless suffixed `_ms`, angles in degrees, mass in mass units (mu), power in power units (pu). Every field below is used by the documented gameplay rules; unknown fields should be rejected by the loader.

## Weapon (`data/weapons/<id>.json`)
| Field | Type | Meaning |
|---|---|---|
| `id` | string | Unique weapon id (`wpn_*`). |
| `display_name` | string | UI name. |
| `size` | enum | `small`/`medium`/`large`/`extra_large`. |
| `mount_type` | enum | `fixed` or `turret`. |
| `sprite` | object | `file`, `width`, `height`, `pivot{x,y}` (mount rotation axis). |
| `muzzle.offset{x,y}` | int | Projectile spawn point relative to the sprite pivot, weapon facing up (so Y is negative). |
| `muzzle.flash_effect_id` | string | Effect played at the muzzle. |
| `projectile_id` | string | Projectile definition fired. |
| `mass` | number | Equipment mass (mu). |
| `power_draw` | number | Continuous power requirement while installed (pu). |
| `energy_per_shot` | number | Energy pool cost per shot (0 for weapons that use other ammo). |
| `damage` | number | Damage per projectile hit. |
| `damage_type` | enum | `energy`, `kinetic`, `explosive` (for armour/shield rules you define later). |
| `fire_rate` | number | Shots per second. |
| `projectile_speed` | number | Muzzle speed px/s (authoritative; projectile files carry no speed). |
| `range` | number | Maximum travel distance px; projectile lifetime = `range / projectile_speed`. |
| `spread_deg` | number | Random half-angle added to each shot (0 = perfectly accurate). |
| `tags` | string[] | Used by hardpoint `restrictions` (`energy`, `ballistic`, `missile`, `spinal`). |
| `turret_turn_rate_deg_s` | number, **only for `turret` weapons** | Aim rotation speed. |

## Projectile (`data/projectiles/<id>.json`)
| Field | Type | Meaning |
|---|---|---|
| `id`, `display_name`, `sprite` | | As above; sprite faces up, pivot = centre. |
| `hit_radius` | number | Collision circle radius px. |
| `impact_effect_id` | string | Effect on hit/expiry. |
| `blast_radius` | number, optional | Area damage radius px (explosive/heavy rounds). |
| `homing` | object, optional | `turn_rate_deg_s` (max steering), `acquire_cone_deg` (full cone in front used to pick a target). Homing missiles keep `projectile_speed` from the weapon. |

## Effect / animation (`data/effects/<id>.json`)
`id`, `display_name`, `sprite{file, frame_width, frame_height, frame_count, pivot{x,y}}`, `frame_duration_ms`, `loop`. Details in ANIMATION_SPEC.md.

## Commodity (`data/salvage/commodities.json`)
`commodities[]`: `id` (`com_*`), `display_name`, `sprite`, `mass_per_unit` (counts toward hull `cargo_capacity`). Prices are not defined here; they belong to your economy.

## Salvage container (`data/salvage/container_generic.json`)
| Field | Meaning |
|---|---|
| `id`, `display_name`, `sprite` | As above. |
| `collect_radius` | Distance px at which the Loot button / auto-pickup works. |
| `despawn_after_s` | Seconds before the container disappears. |
| `drift.max_speed`, `drift.max_spin_deg_s` | Initial random drift speed (px/s) and spin. |
| `loot_table[]` | `commodity_id`, `min_quantity`, `max_quantity`, `weight` (relative probability); pick entries by weight when spawning. |

## Loadout (`data/examples/loadout_*.json`)
See SHIP_LAYOUT_SPEC.md. Hull fields are also defined there.

## Enumerations
`size`: small, medium, large, extra_large - `mount_type`: fixed, turret - `damage_type`: energy, kinetic, explosive - `hull_class`: runner, destroyer, corvette, frigate, battleship, flagship - `configuration`: civilian, cargo, military.

## Weapon table (generated)
| Id | Size | Mount | Mass | Power | E/shot | Damage | Rate/s | Speed | Range | Sprite |
|---|---|---|---|---|---|---|---|---|---|---|"""]
for k, w in weapons.items():
    t.append(f"| `{k}` | {w['size']} | {w['mount_type']} | {w['mass']} | {w['power_draw']} | {w['energy_per_shot']} | {w['damage']} {w['damage_type']} | {w['fire_rate']} | {w['projectile_speed']} | {w['range']} | {w['sprite']['width']}x{w['sprite']['height']} |")
t += ['', '## Examples (verbatim copies of files in the pack)', '', '### Player ship', jdump('data/ships/ship_player_runner.json'), '### Cargo ship', jdump('data/ships/ship_cargo_hauler.json'),
      '### Pirate ship', jdump('data/ships/ship_pirate_interceptor.json'), '### Weapon: laser cannon', jdump('data/weapons/wpn_laser_cannon.json'),
      '### Weapon: heavy cannon', jdump('data/weapons/wpn_heavy_cannon.json'), '### Weapon: autocannon turret', jdump('data/weapons/wpn_turret_autocannon.json'),
      '### Weapon: missile launcher', jdump('data/weapons/wpn_missile_launcher.json'), '### Projectile: guided missile', jdump('data/projectiles/proj_missile.json'),
      '### Animated explosion', jdump('data/effects/fx_explosion_large.json'), '### Salvage container', jdump('data/salvage/container_generic.json'),
      '### Ship loadout (separate from the hull)', jdump('data/examples/loadout_player_example.json'),
      '', 'Other hulls, weapons, projectiles and effects follow the same shapes; see the files in `data/`.']
W('WEAPON_DATA_SCHEMA.md', '\n'.join(t))


# ---------------- ASSET INTEGRATION ----------------
W('ASSET_INTEGRATION.md', r"""
# Asset Integration Guide (C17 / SDL3 / CMake / Android)

Nothing here assumes the engine already has an asset manager. The pack is plain PNG + JSON; the snippets below are a minimal, self-contained way to consume it. They are illustrative reference code, not part of the pack's deliverables, and were not compiled against your repository (it was not accessible when this pack was produced) - adapt names to your codebase. Do not let this guide change your engine's language or architecture.

## 1. Where to put files
- Copy `assets/` and `data/` next to the executable (desktop) and into `android/app/src/main/assets/` (Android). Keep relative paths such as `assets/ships/ship_player_runner.png` exactly as written in the JSON.
- CMake (desktop): `file(COPY ${CMAKE_SOURCE_DIR}/StarForge_Asset_Pack/assets StarForge_Asset_Pack/data DESTINATION ${CMAKE_BINARY_DIR})` or a `add_custom_command` that copies on change. Android: point Gradle `sourceSets.main.assets.srcDirs` at the folder containing `assets/` and `data/`.
- SDL's file API (`SDL_IOFromFile`, `SDL_LoadFile`) reads APK assets on Android with the same relative paths, so one code path serves both platforms. Do not use `fopen` for Android assets.

## 2. Loading PNGs
Pick one (each is permissively licensed; record whichever you add in LICENSES.md):
- **SDL3_image**: `SDL_Texture *t = IMG_LoadTexture(renderer, path);`
- **stb_image** (public domain/MIT): decode to RGBA8 then `SDL_CreateSurfaceFrom(w, h, SDL_PIXELFORMAT_RGBA32, pixels, w*4)` and `SDL_CreateTextureFromSurface`.
- Newer SDL3 releases also include built-in image loading helpers (`SDL_LoadSurface` / `SDL_LoadPNG`); check your SDL version's headers before relying on them.

Immediately after creating each texture:
```c
SDL_SetTextureScaleMode(tex, SDL_SCALEMODE_NEAREST);       /* mandatory for pixel art */
SDL_SetTextureBlendMode(tex, SDL_BLENDMODE_BLEND);         /* PNGs use straight alpha */
```
Frame setup:
```c
SDL_SetRenderLogicalPresentation(renderer, 320, 180, SDL_LOGICAL_PRESENTATION_INTEGER_SCALE);
```
On OpenGL ES 2.0, non-power-of-two textures are fine for clamped, non-mipmapped use, which is how SDL draws them. Every PNG here is small (largest: 512x64 strip, 320x180 background), far below GLES2 minimum texture limits.

## 2. A minimal asset cache
```c
typedef struct { SDL_Texture *tex; int w, h; float pivot_x, pivot_y; } SfSprite;
typedef struct { char path[96]; SfSprite spr; } SfCacheEntry;
static SfCacheEntry g_cache[256]; static int g_cache_n;

const SfSprite *sf_sprite_get(SDL_Renderer *r, const char *path, float px, float py) {
    for (int i = 0; i < g_cache_n; i++) if (!strcmp(g_cache[i].path, path)) return &g_cache[i].spr;
    SDL_Texture *t = IMG_LoadTexture(r, path);
    if (!t) { SDL_Log("missing asset %s: %s", path, SDL_GetError()); return NULL; }
    SDL_SetTextureScaleMode(t, SDL_SCALEMODE_NEAREST);
    SfCacheEntry *e = &g_cache[g_cache_n++];
    snprintf(e->path, sizeof e->path, "%s", path);
    e->spr = (SfSprite){ t, t->w, t->h, px, py };
    return &e->spr;
}
```
(`t->w`/`t->h` are accessible in SDL3; otherwise use `SDL_GetTextureSize`.) Always load a given path once; many sprites sharing one texture batch automatically only if they are the same texture, so a later optimisation is packing sprites into one atlas at build time. For ~80 small textures this is not needed for a first integration.

## 3. Loading JSON
SDL has no JSON parser. Use any small MIT-licensed C parser (cJSON, parson, ...) and add its licence to `LICENSES/`. Pattern:
```c
char *txt = SDL_LoadFile("data/weapons/wpn_laser_cannon.json", &len);   /* works with APK assets */
cJSON *root = cJSON_ParseWithLength(txt, len);
SfWeaponDef w = {0};
w.mass        = (float)cJSON_GetObjectItem(root, "mass")->valuedouble;
w.power_draw  = (float)cJSON_GetObjectItem(root, "power_draw")->valuedouble;
/* ... map "size" and "mount_type" strings to enums, resolve "projectile_id" via a lookup table ... */
SDL_free(txt); cJSON_Delete(root);
```
Load order: effects -> projectiles -> weapons -> hulls -> commodities/containers -> loadouts, so id references can be resolved as each file loads. Fail loudly on unknown ids or enum strings; run `tools/validate_pack.py` in CI to catch the same problems on the data side.

## 4. Drawing
See SPRITE_COORDINATES.md for transforms. Per frame:
1. Background: draw `bg_nebula_320x180.png` once, then the three star tile layers with parallax (tile with a double loop; `SDL_RenderTextureTiled` also works).
2. Planets, station, asteroids, wreckage, containers/pickups.
3. For each ship: exhaust effects at `exhaust_points` (behind), hull sprite, then each installed weapon sprite at `hardpoint.position` rotated by hull heading + offset (+ turret aim).
4. Projectiles, then effects, then UI.
```c
void sf_draw_sprite(SDL_Renderer *r, const SfSprite *s, float wx, float wy, float angle_deg) {
    SDL_FRect d = { floorf(wx - s->pivot_x), floorf(wy - s->pivot_y), (float)s->w, (float)s->h };
    SDL_FPoint c = { s->pivot_x, s->pivot_y };
    SDL_RenderTextureRotated(r, s->tex, NULL, &d, angle_deg, &c, SDL_FLIP_NONE);
}
void sf_draw_frame(SDL_Renderer *r, const SfSprite *sheet, int fw, int fh, int frame,
                   float wx, float wy, float px, float py, float angle_deg) {
    SDL_FRect src = { (float)(frame * fw), 0, (float)fw, (float)fh };
    SDL_FRect d = { floorf(wx - px), floorf(wy - py), (float)fw, (float)fh };
    SDL_FPoint c = { px, py };
    SDL_RenderTextureRotated(r, sheet->tex, &src, &d, angle_deg, &c, SDL_FLIP_NONE);
}
```
Draw a weapon with its hull: weapon world position = `ship_pos + rotate(hardpoint.position, heading)`, angle = `heading + hardpoint.orientation_offset_deg`.

## 5. Mobile UI
- Joystick: draw `ui_joystick_base` at the touch-down point (or a fixed corner); draw `ui_joystick_knob` at base centre + clamped finger offset (max radius ~20 px internal).
- Buttons: `ui_btn_*_up` normally, `_down` while a finger is inside; hit-test with a radius slightly larger than 16 px internal (e.g. 20) to forgive thumbs.
- Panels/buttons: `SDL_RenderTexture9Grid` with margins 6/6/6/6.
- Icons 16x16 next to numbers drawn with your own bitmap font (none is shipped: no text is baked into any asset).
- Reticles: tint with `SDL_SetTextureColorMod` / `SDL_SetTextureAlphaMod`; `ui_offscreen_arrow` rotates around its centre to point at the target.
- Keep safe-area insets (notches) out of the 320x180 playfield when widening the viewport.

## 6. Salvage and inventory
Spawn a container from `container_generic.json`: roll the `loot_table`, store the results on the entity, and play `fx_explosion_small` when the hull that dropped it dies. Inventory icons are the `salvage_*` sprites referenced by `commodities.json`.

## 7. Checklist
- [ ] Nearest filtering on every texture.
- [ ] Integer scaling / logical presentation 320x180.
- [ ] Hardpoint and exhaust coordinates treated as pivot-relative.
- [ ] Animation timing from `frame_duration_ms`.
- [ ] Both compatibility and resource checks in WEAPON_MOUNTING_SPEC.md implemented as separate steps.
- [ ] `python3 tools/validate_pack.py` passes after any asset or data edit.
""")

# ---------------- LICENSES ----------------
n = len(man)
W('LICENSES.md', f"""
# Licences and Attribution

## Summary
**Every asset in this pack is original work generated by the script `tools/generate_assets.py`. No third-party artwork, fonts, sounds, code or data are included or were used as a source.** Therefore:
- There are **no third-party attribution requirements**.
- There are **no third-party licence files** to preserve (`LICENSES/` explains this).
- No assets were ripped from, traced from or modelled on any existing commercial game.

## Licence of the original assets: owner decision required
This pack was produced on behalf of the Star-Forge repository owner and the owner decides the licence. **No licence has been applied or verified for you**; until you add one, treat the pack as "all rights reserved by the repository owner". Common options: CC0 1.0 (maximal reuse, no attribution) or the same licence as the rest of Star-Forge. Once decided, put the licence text in `LICENSES/` and update this file. (Copyright status of procedurally generated art can vary by jurisdiction; confirm with your own counsel if it matters for distribution.)

## Sourcing audit
The brief preferred permissively licensed existing art. It could not be used because the producing environment's network allow-list did not include the candidate sites; nothing was downloaded and no licence could be verified, so nothing was included ("if its license is unclear, leave it out").

| Candidate source | Accessed? | Result |
|---|---|---|
| kenney.nl/assets (CC0 packs) | No (network not permitted) | Nothing downloaded or included |
| kenney-assets.itch.io | No | Nothing downloaded or included |
| opengameart.org | No | Nothing downloaded or included |
| itch.io pixel-art space assets | No | Nothing downloaded or included |

If you later add third-party art: verify the licence **of each individual pack**, store its licence/readme in `LICENSES/<pack>/`, and add a row below.

| Asset(s) | Source URL | Creator | Licence | Attribution required | Licence file |
|---|---|---|---|---|---|
| *(none)* | | | | | |

## Tooling
`tools/*.py` use Python 3 and Pillow (HPND-style licence). Pillow is a build-time dependency only and is not redistributed in this pack. The pack contains {n} sprite/sheet PNGs plus generated frames, all produced by the included script.
""")
with open(os.path.join(ROOT, 'LICENSES', 'README.md'), 'w') as f:
    f.write("""# LICENSES folder

This folder is where original licence and attribution files for **third-party** assets must be stored (one sub-folder per source pack).

**Currently empty of third-party licences on purpose:** this pack contains only original, script-generated art and no third-party material. See `../docs/LICENSES.md` for the full audit. When the repository owner chooses a licence for the original assets, place its text here (for example `LICENSE-assets.txt`).
""")

# ---------------- README ----------------
cnt = {c: len([m for m in man if m['category'] == c]) for c in cats}
nframes = sum(m['frames'] for m in man if m['frames_dir'])
W('../README.md', f"""
# Star-Forge Asset Pack

Game-ready PNG sprites, JSON data definitions and integration documentation for the Star-Forge 2D top-down space RPG (C17 / SDL3 / CMake / Android NDK, 320x180 internal resolution). Engine-agnostic: nothing in the engine is modified or assumed.

## What is included
| Category | Files | Highlights |
|---|---|---|
| `assets/ships` | {cnt['ships']} | Player Runner, Pirate Interceptor, Cargo Hauler, Civilian Transport, Military Destroyer, Military Frigate (hulls only, with empty mount pads) |
| `assets/weapons` | {cnt['weapons']} | Laser, Pulse, Heavy Cannon, Missile Launcher, Railgun, Autocannon Turret (separate from hulls) |
| `assets/projectiles` | {cnt['projectiles']} | Blue/red laser, pulse orb, heavy shell, rail slug, missile |
| `assets/effects` | {cnt['effects']} sheets ({nframes} frames, also as individual PNGs) | 4 engine exhausts, 2 muzzle flashes, 2 explosions, damage smoke, damage fire |
| `assets/asteroids` | {cnt['asteroids']} | 8 asteroids (small, large, ore) + 3 wreckage pieces |
| `assets/stations` | {cnt['stations']} | Ring space station |
| `assets/planets` | {cnt['planets']} | Terran, gas giant, moon, star, dashed orbit ring |
| `assets/salvage` | {cnt['salvage']} | Food, Medicine, Equipment, Metal, Luxury, Fuel, Weapon salvage, generic container, large container |
| `assets/ui` | {cnt['ui']} | Joystick base/knob, Fire/Boost/Loot buttons (up/down), icons (health, energy, fuel, credits, inventory, weapon), reticles, selection ring, off-screen arrow, 9-slice panel and buttons |
| `assets/backgrounds` | {cnt['backgrounds']} | Nebula backdrop 320x180, three parallax star tiles |
| `data/` | {len(glob.glob(os.path.join(ROOT, 'data', '**', '*.json'), recursive=True))} JSON files | 6 hulls with hardpoints, 6 weapons, 6 projectiles, 10 effects, commodities, salvage container, 3 loadouts |
| `docs/` | 9 specs + CSV inventory | See below; `preview_*.png` are review aids, not game assets |
| `tools/` | | `generate_assets.py`, `generate_docs.py`, `validate_pack.py`, `make_preview.py` (Python 3 + Pillow) |

## Start here
1. `docs/ASSET_INTEGRATION.md` - loading and drawing with SDL3.
2. `docs/SPRITE_COORDINATES.md` - pivots, hardpoint maths, rotation.
3. `docs/SHIP_LAYOUT_SPEC.md`, `docs/WEAPON_MOUNTING_SPEC.md`, `docs/WEAPON_DATA_SCHEMA.md` - data-driven ships and weapons.
4. `docs/ANIMATION_SPEC.md`, `docs/ART_STYLE_GUIDE.md`, `docs/ASSET_CATALOG.md`.

## Quality assurance
`python3 tools/validate_pack.py` checks that every PNG opens and has real transparency, sizes in JSON/manifest match the files, all id and file references resolve, mount pads lie on the hull, there are no duplicate images, the example loadouts satisfy size/mount/mass/power rules, and all docs exist. Regenerate everything with `python3 tools/generate_assets.py && python3 tools/generate_docs.py`.

## Licensing
All art is original and script-generated; no third-party assets are included, so no attribution is required. **The repository owner must still choose and apply a licence** - see `docs/LICENSES.md`.

## Gaps / assets still needing original artwork
- **Battleship and Flagship hulls** (and further hull/configuration combinations) - not created, per "do not make 18 arbitrary ships".
- **Third-party high-quality art** (Kenney, OpenGameArt, itch.io) was not sourced: the build environment could not reach those sites and the Star-Forge repository was not accessible, so the existing asset pipeline could not be inspected. Verify the integration guide against your code.
- The military hulls (Destroyer, Frigate) are serviceable but plainer and rounder than the smaller ships; a human pixel artist should polish them.
- Planet surface close-ups, shields/shield-hit effects, shipyard/UI screens, fonts, sound: not included.
- Gameplay numbers in JSON (mass, power, damage, speeds, health) are consistent starting values, not balanced.
- **Fusion mechanic**: deliberately not implemented; marked as an unresolved design decision.
""")
print('docs done')
