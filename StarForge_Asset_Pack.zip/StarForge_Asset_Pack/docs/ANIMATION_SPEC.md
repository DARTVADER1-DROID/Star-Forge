# Animation Specification

## Frame layout
- Every animation is a **single horizontal strip**: frame `i` occupies `x = i * frame_width`, `y = 0`, size `frame_width x frame_height`. All frames in a strip have identical dimensions.
- Frame order is playback order (0 first). Individual frames are also provided as `assets/effects/frames/<sprite>/<sprite>_NN.png` (NN zero-padded) for debugging.
- Timing is `frame_duration_ms` per frame (constant). `loop: true` wraps to frame 0; `loop: false` plays once and the effect instance is removed after the last frame has been shown for its full duration.
- Pivot is in frame-local pixels from the frame's top-left; the pivot is the point placed at the effect's world position.

## Effect table (generated from data/effects/*.json)
| Effect id | Sheet | Frame | Frames | ms/frame | fps | Total ms | Loop | Pivot | Anchor semantics |
|---|---|---|---|---|---|---|---|---|---|

## Playback rules
1. **Exhaust** (looping): start when thrust > 0, stop (or fade out by skipping draw) when thrust = 0. Boost may draw it at 1.5x scale (integer-rounded) or use the `exhaust_large_blue` sheet. Give each instance a random start frame so engines do not pulse in unison.
2. **Muzzle flash** (one-shot, 3 frames x 40 ms): spawn when a weapon fires at `weapon pivot + rotate(muzzle.offset)`, rotated to the weapon's world angle.
3. **Explosion** (one-shot, 8 frames x 70 ms = 560 ms): spawn on projectile impact or ship death. Use `fx_explosion_large` for hulls of 48 px and above and for missiles. Chaining several small explosions at random hull points before the large one is recommended for frigates.
4. **Damage smoke / fire** (looping): suggestion only - smoke below 50% health, fire below 25%, anchored at a fixed random point inside the hull. Thresholds are gameplay tuning, not asset data.
5. Draw order (back to front): background layers, planets/stations, asteroids/wreckage/pickups, exhaust, ship hulls, weapons, projectiles, damage effects, explosions/flashes, UI.

## Reference update code (C17)
```c
typedef struct { const SfAnimDef *def; float t_ms; bool done; } SfAnimInst;

static void sf_anim_update(SfAnimInst *a, float dt_ms) {
    if (a->done) return;
    a->t_ms += dt_ms;
    float total = (float)(a->def->frame_duration_ms * a->def->frame_count);
    if (a->t_ms >= total) {
        if (a->def->loop) a->t_ms = fmodf(a->t_ms, total);
        else { a->t_ms = total - 0.001f; a->done = true; }
    }
}
static int sf_anim_frame(const SfAnimInst *a) {
    return (int)(a->t_ms / (float)a->def->frame_duration_ms);   /* 0 .. frame_count-1 */
}
/* source rect: { frame * frame_width, 0, frame_width, frame_height } */
```
