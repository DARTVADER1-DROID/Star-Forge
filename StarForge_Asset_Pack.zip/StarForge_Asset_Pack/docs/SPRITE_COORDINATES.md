# Sprite Coordinates, Pivots, Scaling and Rotation

## Conventions
- **Sprite-local space**: origin at the sprite's **top-left corner**, +X right, +Y down, units = art pixels. Pixel `(0,0)` covers the area `[0,1)x[0,1)`.
- **Ship-local space**: origin at the ship sprite's **pivot**; same axes. The pivot of every hull is its geometric centre `(width/2, height/2)`, a point on a pixel *edge* (hulls have even dimensions). A hardpoint at `(x,y)` is therefore at sprite pixel position `(width/2 + x, height/2 + y)`.
- **Forward** is up: ship-local `(0,-1)`. Heading angle 0 = north; positive angles rotate **clockwise** on screen (matches SDL's `angle` parameter, which is in degrees).
- All coordinates in JSON are integers in internal 320x180 pixels, never screen pixels.

## Transforms
Rotate a ship-local vector `(x,y)` by heading `h` (radians, clockwise, y-down):
```c
float c = cosf(h), s = sinf(h);
float wx = ship.x + (x * c - y * s);
float wy = ship.y + (x * s + y * c);
/* forward unit vector for heading h: (sin h, -cos h)   e.g. h = 90deg -> (1, 0) = east */
```
Weapon world angle = `ship.heading + hardpoint.orientation_offset_deg (+ turret aim offset within the arc)`.
Muzzle world position = weapon world position + rotate(muzzle.offset, weapon world angle). `muzzle.offset` is relative to the weapon sprite pivot; forward is negative Y.

## Drawing with SDL3
```c
/* ship sprite centred on world position, rotated about its pivot */
SDL_FRect dst = { (ship.x - cam.x) * scale - pivot.x * scale,
                  (ship.y - cam.y) * scale - pivot.y * scale,
                  spr.w * scale, spr.h * scale };
SDL_FPoint center = { pivot.x * scale, pivot.y * scale };   /* relative to dst top-left */
SDL_RenderTextureRotated(r, tex, NULL, &dst, heading_deg, &center, SDL_FLIP_NONE);
```
With `SDL_SetRenderLogicalPresentation(r, 320, 180, SDL_LOGICAL_PRESENTATION_INTEGER_SCALE)` SDL applies the integer scale for you, so use `scale = 1`.
Rotated pixel art looks coarse at arbitrary angles; this is accepted. If it bothers you later, pre-render 32 rotations per hull at load time with nearest sampling - not needed for the first integration.
Snap sprite destination positions to whole internal pixels (`floorf`) when the ship is not rotating to avoid shimmer.

## Scaling
Integer scale only (see ART_STYLE_GUIDE.md). Never scale sprites individually by fractional factors. UI uses the same internal space; touch targets: the 32 px buttons become 192 px at 6x, comfortably above 48 dp on typical phones.

## Pivot table (generated)
| Asset | Size | Pivot | Notes |
|---|---|---|---|
| `ship_player_runner.png` | 32x32 | (16,16) | ships |
| `ship_pirate_interceptor.png` | 32x32 | (16,16) | ships |
| `ship_cargo_hauler.png` | 48x48 | (24,24) | ships |
| `ship_civilian_transport.png` | 48x48 | (24,24) | ships |
| `ship_military_destroyer.png` | 64x64 | (32,32) | ships |
| `ship_military_frigate.png` | 96x96 | (48,48) | ships |
| `wpn_laser_cannon.png` | 16x16 | (8,10) | weapons |
| `wpn_pulse_cannon.png` | 16x16 | (8,9) | weapons |
| `wpn_heavy_cannon.png` | 24x24 | (12,15) | weapons |
| `wpn_missile_launcher.png` | 24x24 | (12,12) | weapons |
| `wpn_railgun.png` | 24x40 | (12,30) | weapons |
| `wpn_turret_autocannon.png` | 16x16 | (8,8) | weapons |
| `proj_laser_blue.png` | 4x12 | (2,6) | projectiles |
| `proj_laser_red.png` | 4x12 | (2,6) | projectiles |
| `proj_pulse_orb.png` | 8x8 | (4,4) | projectiles |
| `proj_heavy_shell.png` | 8x12 | (4,6) | projectiles |
| `proj_rail_slug.png` | 4x24 | (2,12) | projectiles |
| `proj_missile.png` | 8x16 | (4,8) | projectiles |
| `exhaust_blue.png` | 8x16 | (4,0) | effects |
| `exhaust_orange.png` | 8x16 | (4,0) | effects |
| `exhaust_red.png` | 8x16 | (4,0) | effects |
| `exhaust_large_blue.png` | 16x32 | (8,0) | effects |
| `muzzle_small.png` | 16x16 | (8,14) | effects |
| `muzzle_large.png` | 24x24 | (12,22) | effects |
| `explosion_small.png` | 32x32 | (16,16) | effects |
| `explosion_large.png` | 64x64 | (32,32) | effects |
| `damage_smoke.png` | 16x16 | (8,14) | effects |
| `damage_fire.png` | 16x16 | (8,14) | effects |
| `salvage_food.png` | 16x16 | (8,8) | salvage |
| `salvage_medicine.png` | 16x16 | (8,8) | salvage |
| `salvage_equipment.png` | 16x16 | (8,8) | salvage |
| `salvage_metal.png` | 16x16 | (8,8) | salvage |
| `salvage_luxury.png` | 16x16 | (8,8) | salvage |
| `salvage_fuel.png` | 16x16 | (8,8) | salvage |
| `salvage_weapon.png` | 16x16 | (8,8) | salvage |
| `salvage_container_generic.png` | 16x16 | (8,8) | salvage |
| `container_large_24.png` | 24x24 | (12,12) | salvage |
| `ui_joystick_base.png` | 64x64 | (32,32) | ui |
| `ui_joystick_knob.png` | 32x32 | (16,16) | ui |
| `ui_btn_fire_up.png` | 32x32 | (16,16) | ui |
| `ui_btn_fire_down.png` | 32x32 | (16,16) | ui |
| `ui_btn_boost_up.png` | 32x32 | (16,16) | ui |
| `ui_btn_boost_down.png` | 32x32 | (16,16) | ui |
| `ui_btn_loot_up.png` | 32x32 | (16,16) | ui |
| `ui_btn_loot_down.png` | 32x32 | (16,16) | ui |
| `ui_icon_health.png` | 16x16 | (8,8) | ui |
| `ui_icon_energy.png` | 16x16 | (8,8) | ui |
| `ui_icon_fuel.png` | 16x16 | (8,8) | ui |
| `ui_icon_credits.png` | 16x16 | (8,8) | ui |
| `ui_icon_inventory.png` | 16x16 | (8,8) | ui |
| `ui_icon_weapon.png` | 16x16 | (8,8) | ui |
| `ui_reticle_target.png` | 32x32 | (16,16) | ui |
| `ui_reticle_lock.png` | 32x32 | (16,16) | ui |
| `ui_selection_ring.png` | 32x32 | (16,16) | ui |
| `ui_offscreen_arrow.png` | 16x16 | (8,8) | ui |

Asteroids, planets, stations, wreckage: pivot = centre. Backgrounds have no pivot (tile/scroll them).

## Nine-slice UI
| File | Size | Margins L/T/R/B | Stretch |
|---|---|---|---|
| `ui_panel_9slice.png` | 24x24 | 6/6/6/6 | centre and edges |
| `ui_button_9slice_normal.png` / `_pressed` / `_disabled` | 24x24 | 6/6/6/6 | centre and edges |

`SDL_RenderTexture9Grid(r, tex, NULL, 6, 6, 6, 6, 1.0f, &dst);` Use integer destination sizes. Corner pixels are transparent to give rounded corners.

## Weapon sprite pivots
A weapon pivot is the **mount rotation axis**: place it exactly on the hardpoint position. Fixed weapons point along the hardpoint's orientation; turrets rotate about the pivot.

## Parallax star tiles
`stars_*_128.png` tile seamlessly (no star within 2 px of an edge). Draw a grid of tiles offset by `-fmodf(cam.x * factor, 128)`; suggested factors far 0.1, mid 0.25, near 0.5. Stars never wrap across a tile edge, so there are no seams.
