# Weapon, Projectile and Related Data Schema

All JSON is UTF-8, `schema_version: 1`. Paths are relative to the pack root. **Units**: distances in internal pixels (320x180 space), speeds in px/s, time in seconds unless suffixed `_ms`, angles in degrees, mass in mass units (mu), power in power units (pu). Every field below is used by the documented gameplay rules; unknown fields should be rejected by the loader.

## Weapon (`data/weapons/<id>.json`)
| Field | Type | Meaning |
|---|---|---|
| `id` | string | Unique weapon id (`wpn_*`). |
| `display_name` | string | UI name. |
| `size` | enum | `small`/`medium`/`large`/`extra_large`. |
| `mount_type` | enum | `fixed` or `turret`. |
| `sprite` | object | `file`, `width`, `height`, `pivot{x,y}` (mount rotation axis). |
| `muzzle.offset{x,y}` | int | Projectile spawn point relative to the sprite pivot, weapon facing up (so Y is negative). |
| `muzzle.flash_effect_id` | string | Effect played at the muzzle. |
| `projectile_id` | string | Projectile definition fired. |
| `mass` | number | Equipment mass (mu). |
| `power_draw` | number | Continuous power requirement while installed (pu). |
| `energy_per_shot` | number | Energy pool cost per shot (0 for weapons that use other ammo). |
| `damage` | number | Damage per projectile hit. |
| `damage_type` | enum | `energy`, `kinetic`, `explosive` (for armour/shield rules you define later). |
| `fire_rate` | number | Shots per second. |
| `projectile_speed` | number | Muzzle speed px/s (authoritative; projectile files carry no speed). |
| `range` | number | Maximum travel distance px; projectile lifetime = `range / projectile_speed`. |
| `spread_deg` | number | Random half-angle added to each shot (0 = perfectly accurate). |
| `tags` | string[] | Used by hardpoint `restrictions` (`energy`, `ballistic`, `missile`, `spinal`). |
| `turret_turn_rate_deg_s` | number, **only for `turret` weapons** | Aim rotation speed. |

## Projectile (`data/projectiles/<id>.json`)
| Field | Type | Meaning |
|---|---|---|
| `id`, `display_name`, `sprite` | | As above; sprite faces up, pivot = centre. |
| `hit_radius` | number | Collision circle radius px. |
| `impact_effect_id` | string | Effect on hit/expiry. |
| `blast_radius` | number, optional | Area damage radius px (explosive/heavy rounds). |
| `homing` | object, optional | `turn_rate_deg_s` (max steering), `acquire_cone_deg` (full cone in front used to pick a target). Homing missiles keep `projectile_speed` from the weapon. |

## Effect / animation (`data/effects/<id>.json`)
`id`, `display_name`, `sprite{file, frame_width, frame_height, frame_count, pivot{x,y}}`, `frame_duration_ms`, `loop`. Details in ANIMATION_SPEC.md.

## Commodity (`data/salvage/commodities.json`)
`commodities[]`: `id` (`com_*`), `display_name`, `sprite`, `mass_per_unit` (counts toward hull `cargo_capacity`). Prices are not defined here; they belong to your economy.

## Salvage container (`data/salvage/container_generic.json`)
| Field | Meaning |
|---|---|
| `id`, `display_name`, `sprite` | As above. |
| `collect_radius` | Distance px at which the Loot button / auto-pickup works. |
| `despawn_after_s` | Seconds before the container disappears. |
| `drift.max_speed`, `drift.max_spin_deg_s` | Initial random drift speed (px/s) and spin. |
| `loot_table[]` | `commodity_id`, `min_quantity`, `max_quantity`, `weight` (relative probability); pick entries by weight when spawning. |

## Loadout (`data/examples/loadout_*.json`)
See SHIP_LAYOUT_SPEC.md. Hull fields are also defined there.

## Enumerations
`size`: small, medium, large, extra_large - `mount_type`: fixed, turret - `damage_type`: energy, kinetic, explosive - `hull_class`: runner, destroyer, corvette, frigate, battleship, flagship - `configuration`: civilian, cargo, military.

## Weapon table (generated)
| Id | Size | Mount | Mass | Power | E/shot | Damage | Rate/s | Speed | Range | Sprite |
|---|---|---|---|---|---|---|---|---|---|---|
| `wpn_laser_cannon` | small | fixed | 4 | 3 | 2 | 6 energy | 4.0 | 300 | 140 | 16x16 |
| `wpn_pulse_cannon` | medium | fixed | 8 | 6 | 5 | 12 energy | 2.0 | 200 | 120 | 16x16 |
| `wpn_heavy_cannon` | large | fixed | 18 | 4 | 3 | 35 kinetic | 0.8 | 170 | 150 | 24x24 |
| `wpn_missile_launcher` | medium | fixed | 12 | 3 | 0 | 60 explosive | 0.5 | 110 | 180 | 24x24 |
| `wpn_railgun` | extra_large | fixed | 40 | 20 | 25 | 120 kinetic | 0.33 | 500 | 260 | 24x40 |
| `wpn_turret_autocannon` | small | turret | 6 | 3 | 1 | 4 kinetic | 6.0 | 240 | 100 | 16x16 |

## Examples (verbatim copies of files in the pack)

### Player ship
```json
{
  "schema_version": 1,
  "id": "hull_player_runner",
  "display_name": "Runner Mk I",
  "hull_class": "runner",
  "configuration": "civilian",
  "faction": "player",
  "sprite": {
    "file": "assets/ships/ship_player_runner.png",
    "width": 32,
    "height": 32,
    "pivot": {
      "x": 16,
      "y": 16
    }
  },
  "stats": {
    "max_health": 60,
    "mass_empty": 20,
    "equipment_mass_capacity": 24,
    "power_output": 14,
    "cargo_capacity": 8,
    "fuel_capacity": 100,
    "thrust": 90,
    "max_speed": 120,
    "turn_rate_deg_s": 220
  },
  "exhaust_points": [
    {
      "id": "ex_l",
      "position": {
        "x": -4,
        "y": 13
      },
      "effect_id": "fx_exhaust_blue"
    },
    {
      "id": "ex_r",
      "position": {
        "x": 4,
        "y": 13
      },
      "effect_id": "fx_exhaust_blue"
    }
  ],
  "hardpoints": [
    {
      "id": "hp_wing_l",
      "position": {
        "x": -9,
        "y": 5
      },
      "max_size": "small",
      "mount_type": "fixed",
      "orientation_offset_deg": 0,
      "arc_deg": 0
    },
    {
      "id": "hp_wing_r",
      "position": {
        "x": 9,
        "y": 5
      },
      "max_size": "small",
      "mount_type": "fixed",
      "orientation_offset_deg": 0,
      "arc_deg": 0
    },
    {
      "id": "hp_nose",
      "position": {
        "x": 0,
        "y": -2
      },
      "max_size": "medium",
      "mount_type": "fixed",
      "orientation_offset_deg": 0,
      "arc_deg": 0
    }
  ]
}
```
### Cargo ship
```json
{
  "schema_version": 1,
  "id": "hull_cargo_hauler",
  "display_name": "Bulk Hauler",
  "hull_class": "corvette",
  "configuration": "cargo",
  "faction": "civilian",
  "sprite": {
    "file": "assets/ships/ship_cargo_hauler.png",
    "width": 48,
    "height": 48,
    "pivot": {
      "x": 24,
      "y": 24
    }
  },
  "stats": {
    "max_health": 140,
    "mass_empty": 80,
    "equipment_mass_capacity": 30,
    "power_output": 16,
    "cargo_capacity": 60,
    "fuel_capacity": 220,
    "thrust": 45,
    "max_speed": 60,
    "turn_rate_deg_s": 70
  },
  "exhaust_points": [
    {
      "id": "ex_l",
      "position": {
        "x": -11,
        "y": 20
      },
      "effect_id": "fx_exhaust_orange"
    },
    {
      "id": "ex_c",
      "position": {
        "x": 0,
        "y": 20
      },
      "effect_id": "fx_exhaust_orange"
    },
    {
      "id": "ex_r",
      "position": {
        "x": 11,
        "y": 20
      },
      "effect_id": "fx_exhaust_orange"
    }
  ],
  "hardpoints": [
    {
      "id": "hp_nose_turret",
      "position": {
        "x": 0,
        "y": -16
      },
      "max_size": "small",
      "mount_type": "turret",
      "orientation_offset_deg": 0,
      "arc_deg": 270
    },
    {
      "id": "hp_aft_turret",
      "position": {
        "x": 0,
        "y": 16
      },
      "max_size": "small",
      "mount_type": "turret",
      "orientation_offset_deg": 180,
      "arc_deg": 270
    }
  ]
}
```
### Pirate ship
```json
{
  "schema_version": 1,
  "id": "hull_pirate_interceptor",
  "display_name": "Razor Interceptor",
  "hull_class": "runner",
  "configuration": "military",
  "faction": "pirate",
  "sprite": {
    "file": "assets/ships/ship_pirate_interceptor.png",
    "width": 32,
    "height": 32,
    "pivot": {
      "x": 16,
      "y": 16
    }
  },
  "stats": {
    "max_health": 45,
    "mass_empty": 16,
    "equipment_mass_capacity": 14,
    "power_output": 10,
    "cargo_capacity": 2,
    "fuel_capacity": 60,
    "thrust": 120,
    "max_speed": 150,
    "turn_rate_deg_s": 260
  },
  "exhaust_points": [
    {
      "id": "ex_c",
      "position": {
        "x": 0,
        "y": 14
      },
      "effect_id": "fx_exhaust_red"
    }
  ],
  "hardpoints": [
    {
      "id": "hp_claw_l",
      "position": {
        "x": -10,
        "y": -1
      },
      "max_size": "small",
      "mount_type": "fixed",
      "orientation_offset_deg": 0,
      "arc_deg": 0
    },
    {
      "id": "hp_claw_r",
      "position": {
        "x": 10,
        "y": -1
      },
      "max_size": "small",
      "mount_type": "fixed",
      "orientation_offset_deg": 0,
      "arc_deg": 0
    }
  ]
}
```
### Weapon: laser cannon
```json
{
  "schema_version": 1,
  "id": "wpn_laser_cannon",
  "display_name": "Laser Cannon",
  "size": "small",
  "mount_type": "fixed",
  "sprite": {
    "file": "assets/weapons/wpn_laser_cannon.png",
    "width": 16,
    "height": 16,
    "pivot": {
      "x": 8,
      "y": 10
    }
  },
  "muzzle": {
    "offset": {
      "x": 0,
      "y": -9
    },
    "flash_effect_id": "fx_muzzle_small"
  },
  "projectile_id": "proj_laser_blue",
  "mass": 4,
  "power_draw": 3,
  "energy_per_shot": 2,
  "damage": 6,
  "damage_type": "energy",
  "fire_rate": 4.0,
  "projectile_speed": 300,
  "range": 140,
  "spread_deg": 0,
  "tags": [
    "energy"
  ]
}
```
### Weapon: heavy cannon
```json
{
  "schema_version": 1,
  "id": "wpn_heavy_cannon",
  "display_name": "Heavy Cannon",
  "size": "large",
  "mount_type": "fixed",
  "sprite": {
    "file": "assets/weapons/wpn_heavy_cannon.png",
    "width": 24,
    "height": 24,
    "pivot": {
      "x": 12,
      "y": 15
    }
  },
  "muzzle": {
    "offset": {
      "x": 0,
      "y": -14
    },
    "flash_effect_id": "fx_muzzle_large"
  },
  "projectile_id": "proj_heavy_shell",
  "mass": 18,
  "power_draw": 4,
  "energy_per_shot": 3,
  "damage": 35,
  "damage_type": "kinetic",
  "fire_rate": 0.8,
  "projectile_speed": 170,
  "range": 150,
  "spread_deg": 1,
  "tags": [
    "ballistic"
  ]
}
```
### Weapon: autocannon turret
```json
{
  "schema_version": 1,
  "id": "wpn_turret_autocannon",
  "display_name": "Autocannon Turret",
  "size": "small",
  "mount_type": "turret",
  "sprite": {
    "file": "assets/weapons/wpn_turret_autocannon.png",
    "width": 16,
    "height": 16,
    "pivot": {
      "x": 8,
      "y": 8
    }
  },
  "muzzle": {
    "offset": {
      "x": 0,
      "y": -8
    },
    "flash_effect_id": "fx_muzzle_small"
  },
  "projectile_id": "proj_pulse_orb",
  "mass": 6,
  "power_draw": 3,
  "energy_per_shot": 1,
  "damage": 4,
  "damage_type": "kinetic",
  "fire_rate": 6.0,
  "projectile_speed": 240,
  "range": 100,
  "spread_deg": 3,
  "tags": [
    "ballistic"
  ],
  "turret_turn_rate_deg_s": 180
}
```
### Weapon: missile launcher
```json
{
  "schema_version": 1,
  "id": "wpn_missile_launcher",
  "display_name": "Missile Launcher",
  "size": "medium",
  "mount_type": "fixed",
  "sprite": {
    "file": "assets/weapons/wpn_missile_launcher.png",
    "width": 24,
    "height": 24,
    "pivot": {
      "x": 12,
      "y": 12
    }
  },
  "muzzle": {
    "offset": {
      "x": 0,
      "y": -10
    },
    "flash_effect_id": "fx_muzzle_small"
  },
  "projectile_id": "proj_missile",
  "mass": 12,
  "power_draw": 3,
  "energy_per_shot": 0,
  "damage": 60,
  "damage_type": "explosive",
  "fire_rate": 0.5,
  "projectile_speed": 110,
  "range": 180,
  "spread_deg": 0,
  "tags": [
    "missile"
  ]
}
```
### Projectile: guided missile
```json
{
  "schema_version": 1,
  "id": "proj_missile",
  "display_name": "Guided Missile",
  "sprite": {
    "file": "assets/projectiles/proj_missile.png",
    "width": 8,
    "height": 16,
    "pivot": {
      "x": 4,
      "y": 8
    }
  },
  "hit_radius": 4,
  "impact_effect_id": "fx_explosion_large",
  "blast_radius": 24,
  "homing": {
    "turn_rate_deg_s": 140,
    "acquire_cone_deg": 60
  }
}
```
### Animated explosion
```json
{
  "schema_version": 1,
  "id": "fx_explosion_large",
  "display_name": "Large explosion",
  "sprite": {
    "file": "assets/effects/explosion_large.png",
    "frame_width": 64,
    "frame_height": 64,
    "frame_count": 8,
    "pivot": {
      "x": 32,
      "y": 32
    }
  },
  "frame_duration_ms": 70,
  "loop": false
}
```
### Salvage container
```json
{
  "schema_version": 1,
  "id": "container_generic",
  "display_name": "Cargo Container",
  "sprite": {
    "file": "assets/salvage/salvage_container_generic.png",
    "width": 16,
    "height": 16,
    "pivot": {
      "x": 8,
      "y": 8
    }
  },
  "collect_radius": 14,
  "despawn_after_s": 180,
  "drift": {
    "max_speed": 6,
    "max_spin_deg_s": 30
  },
  "loot_table": [
    {
      "commodity_id": "com_food",
      "min_quantity": 1,
      "max_quantity": 4,
      "weight": 30
    },
    {
      "commodity_id": "com_metal",
      "min_quantity": 1,
      "max_quantity": 3,
      "weight": 25
    },
    {
      "commodity_id": "com_fuel",
      "min_quantity": 1,
      "max_quantity": 2,
      "weight": 20
    },
    {
      "commodity_id": "com_equipment",
      "min_quantity": 1,
      "max_quantity": 1,
      "weight": 15
    },
    {
      "commodity_id": "com_luxury",
      "min_quantity": 1,
      "max_quantity": 1,
      "weight": 10
    }
  ]
}
```
### Ship loadout (separate from the hull)
```json
{
  "schema_version": 1,
  "ship_instance_id": "player_01",
  "hull_id": "hull_player_runner",
  "installed": [
    {
      "hardpoint_id": "hp_wing_l",
      "weapon_id": "wpn_laser_cannon"
    },
    {
      "hardpoint_id": "hp_wing_r",
      "weapon_id": "wpn_laser_cannon"
    },
    {
      "hardpoint_id": "hp_nose",
      "weapon_id": "wpn_pulse_cannon"
    }
  ]
}
```

Other hulls, weapons, projectiles and effects follow the same shapes; see the files in `data/`.
