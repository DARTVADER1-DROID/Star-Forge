# Asset Integration Guide (C17 / SDL3 / CMake / Android)

Nothing here assumes the engine already has an asset manager. The pack is plain PNG + JSON; the snippets below are a minimal, self-contained way to consume it. They are illustrative reference code, not part of the pack's deliverables, and were not compiled against your repository (it was not accessible when this pack was produced) - adapt names to your codebase. Do not let this guide change your engine's language or architecture.

## 1. Where to put files
- Copy `assets/` and `data/` next to the executable (desktop) and into `android/app/src/main/assets/` (Android). Keep relative paths such as `assets/ships/ship_player_runner.png` exactly as written in the JSON.
- CMake (desktop): `file(COPY ${CMAKE_SOURCE_DIR}/StarForge_Asset_Pack/assets StarForge_Asset_Pack/data DESTINATION ${CMAKE_BINARY_DIR})` or a `add_custom_command` that copies on change. Android: point Gradle `sourceSets.main.assets.srcDirs` at the folder containing `assets/` and `data/`.
- SDL's file API (`SDL_IOFromFile`, `SDL_LoadFile`) reads APK assets on Android with the same relative paths, so one code path serves both platforms. Do not use `fopen` for Android assets.

## 2. Loading PNGs
Pick one (each is permissively licensed; record whichever you add in LICENSES.md):
- **SDL3_image**: `SDL_Texture *t = IMG_LoadTexture(renderer, path);`
- **stb_image** (public domain/MIT): decode to RGBA8 then `SDL_CreateSurfaceFrom(w, h, SDL_PIXELFORMAT_RGBA32, pixels, w*4)` and `SDL_CreateTextureFromSurface`.
- Newer SDL3 releases also include built-in image loading helpers (`SDL_LoadSurface` / `SDL_LoadPNG`); check your SDL version's headers before relying on them.

Immediately after creating each texture:
```c
SDL_SetTextureScaleMode(tex, SDL_SCALEMODE_NEAREST);       /* mandatory for pixel art */
SDL_SetTextureBlendMode(tex, SDL_BLENDMODE_BLEND);         /* PNGs use straight alpha */
```
Frame setup:
```c
SDL_SetRenderLogicalPresentation(renderer, 320, 180, SDL_LOGICAL_PRESENTATION_INTEGER_SCALE);
```
On OpenGL ES 2.0, non-power-of-two textures are fine for clamped, non-mipmapped use, which is how SDL draws them. Every PNG here is small (largest: 512x64 strip, 320x180 background), far below GLES2 minimum texture limits.

## 2. A minimal asset cache
```c
typedef struct { SDL_Texture *tex; int w, h; float pivot_x, pivot_y; } SfSprite;
typedef struct { char path[96]; SfSprite spr; } SfCacheEntry;
static SfCacheEntry g_cache[256]; static int g_cache_n;

const SfSprite *sf_sprite_get(SDL_Renderer *r, const char *path, float px, float py) {
    for (int i = 0; i < g_cache_n; i++) if (!strcmp(g_cache[i].path, path)) return &g_cache[i].spr;
    SDL_Texture *t = IMG_LoadTexture(r, path);
    if (!t) { SDL_Log("missing asset %s: %s", path, SDL_GetError()); return NULL; }
    SDL_SetTextureScaleMode(t, SDL_SCALEMODE_NEAREST);
    SfCacheEntry *e = &g_cache[g_cache_n++];
    snprintf(e->path, sizeof e->path, "%s", path);
    e->spr = (SfSprite){ t, t->w, t->h, px, py };
    return &e->spr;
}
```
(`t->w`/`t->h` are accessible in SDL3; otherwise use `SDL_GetTextureSize`.) Always load a given path once; many sprites sharing one texture batch automatically only if they are the same texture, so a later optimisation is packing sprites into one atlas at build time. For ~80 small textures this is not needed for a first integration.

## 3. Loading JSON
SDL has no JSON parser. Use any small MIT-licensed C parser (cJSON, parson, ...) and add its licence to `LICENSES/`. Pattern:
```c
char *txt = SDL_LoadFile("data/weapons/wpn_laser_cannon.json", &len);   /* works with APK assets */
cJSON *root = cJSON_ParseWithLength(txt, len);
SfWeaponDef w = {0};
w.mass        = (float)cJSON_GetObjectItem(root, "mass")->valuedouble;
w.power_draw  = (float)cJSON_GetObjectItem(root, "power_draw")->valuedouble;
/* ... map "size" and "mount_type" strings to enums, resolve "projectile_id" via a lookup table ... */
SDL_free(txt); cJSON_Delete(root);
```
Load order: effects -> projectiles -> weapons -> hulls -> commodities/containers -> loadouts, so id references can be resolved as each file loads. Fail loudly on unknown ids or enum strings; run `tools/validate_pack.py` in CI to catch the same problems on the data side.

## 4. Drawing
See SPRITE_COORDINATES.md for transforms. Per frame:
1. Background: draw `bg_nebula_320x180.png` once, then the three star tile layers with parallax (tile with a double loop; `SDL_RenderTextureTiled` also works).
2. Planets, station, asteroids, wreckage, containers/pickups.
3. For each ship: exhaust effects at `exhaust_points` (behind), hull sprite, then each installed weapon sprite at `hardpoint.position` rotated by hull heading + offset (+ turret aim).
4. Projectiles, then effects, then UI.
```c
void sf_draw_sprite(SDL_Renderer *r, const SfSprite *s, float wx, float wy, float angle_deg) {
    SDL_FRect d = { floorf(wx - s->pivot_x), floorf(wy - s->pivot_y), (float)s->w, (float)s->h };
    SDL_FPoint c = { s->pivot_x, s->pivot_y };
    SDL_RenderTextureRotated(r, s->tex, NULL, &d, angle_deg, &c, SDL_FLIP_NONE);
}
void sf_draw_frame(SDL_Renderer *r, const SfSprite *sheet, int fw, int fh, int frame,
                   float wx, float wy, float px, float py, float angle_deg) {
    SDL_FRect src = { (float)(frame * fw), 0, (float)fw, (float)fh };
    SDL_FRect d = { floorf(wx - px), floorf(wy - py), (float)fw, (float)fh };
    SDL_FPoint c = { px, py };
    SDL_RenderTextureRotated(r, sheet->tex, &src, &d, angle_deg, &c, SDL_FLIP_NONE);
}
```
Draw a weapon with its hull: weapon world position = `ship_pos + rotate(hardpoint.position, heading)`, angle = `heading + hardpoint.orientation_offset_deg`.

## 5. Mobile UI
- Joystick: draw `ui_joystick_base` at the touch-down point (or a fixed corner); draw `ui_joystick_knob` at base centre + clamped finger offset (max radius ~20 px internal).
- Buttons: `ui_btn_*_up` normally, `_down` while a finger is inside; hit-test with a radius slightly larger than 16 px internal (e.g. 20) to forgive thumbs.
- Panels/buttons: `SDL_RenderTexture9Grid` with margins 6/6/6/6.
- Icons 16x16 next to numbers drawn with your own bitmap font (none is shipped: no text is baked into any asset).
- Reticles: tint with `SDL_SetTextureColorMod` / `SDL_SetTextureAlphaMod`; `ui_offscreen_arrow` rotates around its centre to point at the target.
- Keep safe-area insets (notches) out of the 320x180 playfield when widening the viewport.

## 6. Salvage and inventory
Spawn a container from `container_generic.json`: roll the `loot_table`, store the results on the entity, and play `fx_explosion_small` when the hull that dropped it dies. Inventory icons are the `salvage_*` sprites referenced by `commodities.json`.

## 7. Checklist
- [ ] Nearest filtering on every texture.
- [ ] Integer scaling / logical presentation 320x180.
- [ ] Hardpoint and exhaust coordinates treated as pivot-relative.
- [ ] Animation timing from `frame_duration_ms`.
- [ ] Both compatibility and resource checks in WEAPON_MOUNTING_SPEC.md implemented as separate steps.
- [ ] `python3 tools/validate_pack.py` passes after any asset or data edit.
