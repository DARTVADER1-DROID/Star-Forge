# Star-Forge Art Style Guide

All art in this pack is original, drawn procedurally by `tools/generate_assets.py` in one consistent style.

## 1. Resolution and scaling
- Internal game resolution: **320x180** (16:9). One art pixel = one internal pixel.
- Scale to the screen with an **integer factor** (`floor(min(screenW/320, screenH/180))`). 1080p landscape = 6x, 720p = 4x. On 20:9 phones either letterbox, or (preferred) widen the visible world horizontally (e.g. 360x162 or 400x180 viewport) rather than stretching.
- Always use **nearest-neighbour** texture filtering. Never use linear filtering or mipmaps.

## 2. Sprite sizes (all dimensions are exact, see ASSET_CATALOG.md)
| Group | Sizes used |
|---|---|
| Small ships (runner class) | 32x32 |
| Medium ships (corvette class) | 48x48 |
| Destroyer | 64x64 |
| Frigate | 96x96 |
| Weapons | 16x16, 24x24, 24x40 (railgun) |
| Projectiles | 4x12, 8x8, 8x12, 4x24, 8x16 |
| Asteroids | 16, 24, 32, 48 square |
| Pickups / UI icons | 16x16 (large container 24x24) |
| Planets / station | 32, 64, 96 square |

Ship, weapon and effect sprites have **even** dimensions so the pivot (the sprite centre) lies on a pixel edge and mirrored art is exactly symmetric.

## 3. Outline
- Every object has a **1 px dark outline**, colour `#0c0f1f` (same for all factions), drawn *inside* the silhouette so the PNG size equals the visible size.
- Effects (flames, flashes, explosions, projectiles) are glow-style and have **no outline**.

## 4. Shading
- Light comes from the **top-left**. Four tones per material: dark (`d`), shadow-mid (`s`), mid (`m`), light (`l`), plus highlight (`h`).
- Rim rule: pixels touching the outline on the top/left side use the light tone; bottom/right side use the dark tone. Right-hand interior is shadow-mid, left-hand interior mid.
- A 2 px light centre ridge runs down symmetric hulls.
- **No anti-aliasing, no gradients, no semi-transparent edges** (exceptions: virtual joystick base, orbit ring, rail slug tail and star-point halos, which use deliberate alpha).

## 5. Orientation
- Top-down view. Every ship, weapon, projectile, flash and exhaust sprite is authored **facing up (north)**. Exhaust flames point down.
- Rotation is applied at runtime (see SPRITE_COORDINATES.md). Never bake rotation into art.

## 6. Faction colour coding (readability at small sizes)
| Role | Hue | Palette (dark, shadow-mid, mid, light, highlight) |
|---|---|---|
| Player | `#1a3566` | `#2457b0` | `#2f6fd1` | `#6fb6ff` | `#d8f2ff` |
| Civilian | `#4a6a63` | `#7fae9a` | `#9fd6bf` | `#d4f5e6` | `#ffffff` |
| Cargo | `#6e4219` | `#b8741f` | `#d98c2b` | `#ffc766` | `#ffe9b0` |
| Pirate | `#3a0c18` | `#7d1626` | `#b3202f` | `#ff6a5a` | `#ffc0a0` |
| Military | `#2e3646` | `#566178` | `#7d8aa0` | `#c3cdd9` | `#f0f4fa` |

Silhouette cues: player = compact arrowhead with swept wings; pirate = spiky forward-swept claws; cargo = long spine flanked by coloured containers; civilian = smooth rounded fuselage with lit windows; military = broad armoured grey hull with panel lines and amber lights.

## 7. Hardpoint pads
Weapons are never painted on hulls. Each hardpoint is marked by a recessed square pad (`#141a2c` / `#4a5a7e` concentric rings). Pad edge length by size class: small 4, medium 6, large 8, extra-large 10 px. Pads are centred exactly on the hardpoint coordinates in `data/ships/*.json`.

## 8. Effects palette
Heat ramp (explosions, flashes, fire): `#fffbe0 #ffe36e #ff9a2e #d7351f #7a1d1a`. Energy ramp: `#ffffff #bff4ff #5cd4ff #2457b0`. Smoke: `#3a3a44 ... #a0a0aa`. Exhaust colour per faction: blue (player/civilian/military), orange (cargo), red (pirate).

## 9. Consistency rules for new art
1. Same outline colour, same light direction, <=5 tones per material.
2. Keep the 320x180 test in mind: a ship must be identifiable by silhouette + dominant colour at 1x.
3. Even dimensions for anything that rotates around its centre.
4. No text baked into game objects.
5. Transparent background, no matte colour in fully transparent pixels.
6. Weapons/turrets are never part of a hull PNG.
7. Preview sheets in `docs/preview_*.png` are review aids only, not game assets.
