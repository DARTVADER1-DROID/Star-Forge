# Asset Catalog

Total sprite/sheet files: **80** (plus individual animation frames). Generated from the files on disk. Pivot is in sprite pixels from the top-left of one frame (see SPRITE_COORDINATES.md).

## ships (6)



| File | Size | Frames | Pivot | Intended use |
|---|---|---|---|---|
| `assets/ships/ship_player_runner.png` | 32x32 | 1 | (16,16) | Runner Mk I (runner/civilian, player) hull, no weapons baked in |
| `assets/ships/ship_pirate_interceptor.png` | 32x32 | 1 | (16,16) | Razor Interceptor (runner/military, pirate) hull, no weapons baked in |
| `assets/ships/ship_cargo_hauler.png` | 48x48 | 1 | (24,24) | Bulk Hauler (corvette/cargo, civilian) hull, no weapons baked in |
| `assets/ships/ship_civilian_transport.png` | 48x48 | 1 | (24,24) | Starliner Transport (corvette/civilian, civilian) hull, no weapons baked in |
| `assets/ships/ship_military_destroyer.png` | 64x64 | 1 | (32,32) | Aegis Destroyer (destroyer/military, military) hull, no weapons baked in |
| `assets/ships/ship_military_frigate.png` | 96x96 | 1 | (48,48) | Bastion Frigate (frigate/military, military) hull, no weapons baked in |

## weapons (6)



| File | Size | Frames | Pivot | Intended use |
|---|---|---|---|---|
| `assets/weapons/wpn_laser_cannon.png` | 16x16 | 1 | (8,10) | Laser Cannon sprite (small, fixed mount); faces up |
| `assets/weapons/wpn_pulse_cannon.png` | 16x16 | 1 | (8,9) | Pulse Cannon sprite (medium, fixed mount); faces up |
| `assets/weapons/wpn_heavy_cannon.png` | 24x24 | 1 | (12,15) | Heavy Cannon sprite (large, fixed mount); faces up |
| `assets/weapons/wpn_missile_launcher.png` | 24x24 | 1 | (12,12) | Missile Launcher sprite (medium, fixed mount); faces up |
| `assets/weapons/wpn_railgun.png` | 24x40 | 1 | (12,30) | Railgun sprite (extra_large, fixed mount); faces up |
| `assets/weapons/wpn_turret_autocannon.png` | 16x16 | 1 | (8,8) | Autocannon Turret sprite (small, turret mount); faces up |

## projectiles (6)



| File | Size | Frames | Pivot | Intended use |
|---|---|---|---|---|
| `assets/projectiles/proj_laser_blue.png` | 4x12 | 1 | (2,6) | Blue Laser Bolt; travels along sprite's up axis |
| `assets/projectiles/proj_laser_red.png` | 4x12 | 1 | (2,6) | Red Laser Bolt; travels along sprite's up axis |
| `assets/projectiles/proj_pulse_orb.png` | 8x8 | 1 | (4,4) | Pulse Orb; travels along sprite's up axis |
| `assets/projectiles/proj_heavy_shell.png` | 8x12 | 1 | (4,6) | Heavy Shell; travels along sprite's up axis |
| `assets/projectiles/proj_rail_slug.png` | 4x24 | 1 | (2,12) | Railgun Slug; travels along sprite's up axis |
| `assets/projectiles/proj_missile.png` | 8x16 | 1 | (4,8) | Guided Missile; travels along sprite's up axis |

## effects (10)

Horizontal strips; frames are equal-sized, left to right. Individual frames are in `assets/effects/frames/<name>/<name>_NN.png`. See ANIMATION_SPEC.md.

| File | Size | Frames | Pivot | Intended use |
|---|---|---|---|---|
| `assets/effects/exhaust_blue.png` | 32x16 | 4 x 8x16 | (4,0) | Blue engine exhaust (small) |
| `assets/effects/exhaust_orange.png` | 32x16 | 4 x 8x16 | (4,0) | Orange engine exhaust (small) |
| `assets/effects/exhaust_red.png` | 32x16 | 4 x 8x16 | (4,0) | Red engine exhaust (small) |
| `assets/effects/exhaust_large_blue.png` | 64x32 | 4 x 16x32 | (8,0) | Blue engine exhaust (large) |
| `assets/effects/muzzle_small.png` | 48x16 | 3 x 16x16 | (8,14) | Small muzzle flash |
| `assets/effects/muzzle_large.png` | 72x24 | 3 x 24x24 | (12,22) | Large muzzle flash |
| `assets/effects/explosion_small.png` | 256x32 | 8 x 32x32 | (16,16) | Small explosion |
| `assets/effects/explosion_large.png` | 512x64 | 8 x 64x64 | (32,32) | Large explosion |
| `assets/effects/damage_smoke.png` | 64x16 | 4 x 16x16 | (8,14) | Looping smoke plume for damaged ships |
| `assets/effects/damage_fire.png` | 64x16 | 4 x 16x16 | (8,14) | Looping flame for heavily damaged ships |

## asteroids (11)

Rocks plus wreckage debris (`wreckage_*`). Wreckage lives here because the required folder list has no separate wreckage folder.

| File | Size | Frames | Pivot | Intended use |
|---|---|---|---|---|
| `assets/asteroids/asteroid_small_01.png` | 16x16 | 1 | (8,8) | Plain small rock |
| `assets/asteroids/asteroid_small_02.png` | 16x16 | 1 | (8,8) | Plain small rock |
| `assets/asteroids/asteroid_small_03.png` | 24x24 | 1 | (12,12) | Plain small rock |
| `assets/asteroids/asteroid_large_01.png` | 32x32 | 1 | (16,16) | Plain large rock |
| `assets/asteroids/asteroid_large_02.png` | 32x32 | 1 | (16,16) | Plain large rock |
| `assets/asteroids/asteroid_large_03.png` | 48x48 | 1 | (24,24) | Plain large rock |
| `assets/asteroids/asteroid_large_04.png` | 48x48 | 1 | (24,24) | Plain large rock |
| `assets/asteroids/asteroid_ore_32.png` | 32x32 | 1 | (16,16) | Ore-bearing large rock |
| `assets/asteroids/wreckage_small.png` | 16x16 | 1 | (8,8) | Ship wreckage debris (static) |
| `assets/asteroids/wreckage_medium.png` | 24x24 | 1 | (12,12) | Ship wreckage debris (static) |
| `assets/asteroids/wreckage_large.png` | 32x32 | 1 | (16,16) | Ship wreckage debris (static) |

## stations (1)



| File | Size | Frames | Pivot | Intended use |
|---|---|---|---|---|
| `assets/stations/station_ring_hub.png` | 96x96 | 1 | (48,48) | Ring space station with docking spokes and solar arrays |

## planets (5)



| File | Size | Frames | Pivot | Intended use |
|---|---|---|---|---|
| `assets/planets/planet_terran_64.png` | 64x64 | 1 | (32,32) | Ocean/land world with ice caps |
| `assets/planets/planet_gas_96.png` | 96x96 | 1 | (48,48) | Banded gas giant with storm |
| `assets/planets/planet_moon_32.png` | 32x32 | 1 | (16,16) | Grey-blue cratered moon |
| `assets/planets/star_yellow_64.png` | 64x64 | 1 | (32,32) | Yellow main-sequence star (flat-lit disc) |
| `assets/planets/orbit_ring_96.png` | 96x96 | 1 | (48,48) | Dashed orbit/target ring, tint at runtime |

## salvage (9)



| File | Size | Frames | Pivot | Intended use |
|---|---|---|---|---|
| `assets/salvage/salvage_food.png` | 16x16 | 1 | (8,8) | Food pickup (Red apple) |
| `assets/salvage/salvage_medicine.png` | 16x16 | 1 | (8,8) | Medicine pickup (White med-kit with red cross) |
| `assets/salvage/salvage_equipment.png` | 16x16 | 1 | (8,8) | Equipment pickup (Steel cog) |
| `assets/salvage/salvage_metal.png` | 16x16 | 1 | (8,8) | Metal pickup (Stack of silver ingots) |
| `assets/salvage/salvage_luxury.png` | 16x16 | 1 | (8,8) | Luxury Goods pickup (Purple gemstone) |
| `assets/salvage/salvage_fuel.png` | 16x16 | 1 | (8,8) | Fuel pickup (Yellow canister with red band) |
| `assets/salvage/salvage_weapon.png` | 16x16 | 1 | (8,8) | Weapon Salvage pickup (Brass ammunition cluster with red tips) |
| `assets/salvage/salvage_container_generic.png` | 16x16 | 1 | (8,8) | Generic cargo container pickup (teal, amber end caps) |
| `assets/salvage/container_large_24.png` | 24x24 | 1 | (12,12) | Large drifting cargo container (red, amber end caps) |

## ui (22)

Inventory item icons are the 16x16 `salvage_*` sprites (same art reused, no duplicate files). Nine-slice margins are in SPRITE_COORDINATES.md.

| File | Size | Frames | Pivot | Intended use |
|---|---|---|---|---|
| `assets/ui/ui_joystick_base.png` | 64x64 | 1 | (32,32) | Virtual joystick base (semi-transparent) |
| `assets/ui/ui_joystick_knob.png` | 32x32 | 1 | (16,16) | Virtual joystick knob |
| `assets/ui/ui_btn_fire_up.png` | 32x32 | 1 | (16,16) | Fire button, released state |
| `assets/ui/ui_btn_fire_down.png` | 32x32 | 1 | (16,16) | Fire button, pressed state |
| `assets/ui/ui_btn_boost_up.png` | 32x32 | 1 | (16,16) | Boost button, released state |
| `assets/ui/ui_btn_boost_down.png` | 32x32 | 1 | (16,16) | Boost button, pressed state |
| `assets/ui/ui_btn_loot_up.png` | 32x32 | 1 | (16,16) | Loot/collect button, released state |
| `assets/ui/ui_btn_loot_down.png` | 32x32 | 1 | (16,16) | Loot/collect button, pressed state |
| `assets/ui/ui_icon_health.png` | 16x16 | 1 | (8,8) | Health (heart) |
| `assets/ui/ui_icon_energy.png` | 16x16 | 1 | (8,8) | Energy (bolt) |
| `assets/ui/ui_icon_fuel.png` | 16x16 | 1 | (8,8) | Fuel (green drop) |
| `assets/ui/ui_icon_credits.png` | 16x16 | 1 | (8,8) | Credits (coin) |
| `assets/ui/ui_icon_inventory.png` | 16x16 | 1 | (8,8) | Inventory/cargo hold (crate) |
| `assets/ui/ui_icon_weapon.png` | 16x16 | 1 | (8,8) | Weapon slot (gun) |
| `assets/ui/ui_reticle_target.png` | 32x32 | 1 | (16,16) | Target bracket (white, tint at runtime) |
| `assets/ui/ui_reticle_lock.png` | 32x32 | 1 | (16,16) | Locked-target bracket with diamond (red) |
| `assets/ui/ui_selection_ring.png` | 32x32 | 1 | (16,16) | Dashed selection ring (green) |
| `assets/ui/ui_offscreen_arrow.png` | 16x16 | 1 | (8,8) | Off-screen target arrow (points up; rotate at runtime) |
| `assets/ui/ui_panel_9slice.png` | 24x24 | 1 | - | Panel background, 9-slice (margins 6 px) |
| `assets/ui/ui_button_9slice_normal.png` | 24x24 | 1 | - | Button background normal, 9-slice (margins 6 px) |
| `assets/ui/ui_button_9slice_pressed.png` | 24x24 | 1 | - | Button background pressed, 9-slice (margins 6 px) |
| `assets/ui/ui_button_9slice_disabled.png` | 24x24 | 1 | - | Button background disabled, 9-slice (margins 6 px) |

## backgrounds (4)

Star layers are 128x128 transparent tiles. `bg_nebula_320x180.png` is the only opaque image in the pack.

| File | Size | Frames | Pivot | Intended use |
|---|---|---|---|---|
| `assets/backgrounds/bg_nebula_320x180.png` | 320x180 | 1 | - | Static opaque nebula backdrop at internal resolution |
| `assets/backgrounds/stars_far_128.png` | 128x128 | 1 | - | Seamlessly tiling parallax star layer (transparent, points kept >=2px from edges) |
| `assets/backgrounds/stars_mid_128.png` | 128x128 | 1 | - | Seamlessly tiling parallax star layer (transparent, points kept >=2px from edges) |
| `assets/backgrounds/stars_near_128.png` | 128x128 | 1 | - | Seamlessly tiling parallax star layer (transparent, points kept >=2px from edges) |

## Data files

| Folder | Files |
|---|---|
| `data/ships/` | `ship_cargo_hauler.json`, `ship_civilian_transport.json`, `ship_military_destroyer.json`, `ship_military_frigate.json`, `ship_pirate_interceptor.json`, `ship_player_runner.json` |
| `data/weapons/` | `wpn_heavy_cannon.json`, `wpn_laser_cannon.json`, `wpn_missile_launcher.json`, `wpn_pulse_cannon.json`, `wpn_railgun.json`, `wpn_turret_autocannon.json` |
| `data/projectiles/` | `proj_heavy_shell.json`, `proj_laser_blue.json`, `proj_laser_red.json`, `proj_missile.json`, `proj_pulse_orb.json`, `proj_rail_slug.json` |
| `data/effects/` | `fx_damage_fire.json`, `fx_damage_smoke.json`, `fx_exhaust_blue.json`, `fx_exhaust_large_blue.json`, `fx_exhaust_orange.json`, `fx_exhaust_red.json`, `fx_explosion_large.json`, `fx_explosion_small.json`, `fx_muzzle_large.json`, `fx_muzzle_small.json` |
| `data/salvage/` | `commodities.json`, `container_generic.json` |
| `data/examples/` | `loadout_cargo_example.json`, `loadout_pirate_example.json`, `loadout_player_example.json` |

## Hull summary

| Hull id | Class / configuration | Faction | Sprite | Hardpoints |
|---|---|---|---|---|
| `hull_player_runner` | runner / civilian | player | `assets/ships/ship_player_runner.png` 32x32 | 3 |
| `hull_pirate_interceptor` | runner / military | pirate | `assets/ships/ship_pirate_interceptor.png` 32x32 | 2 |
| `hull_cargo_hauler` | corvette / cargo | civilian | `assets/ships/ship_cargo_hauler.png` 48x48 | 2 |
| `hull_civilian_transport` | corvette / civilian | civilian | `assets/ships/ship_civilian_transport.png` 48x48 | 1 |
| `hull_military_destroyer` | destroyer / military | military | `assets/ships/ship_military_destroyer.png` 64x64 | 5 |
| `hull_military_frigate` | frigate / military | military | `assets/ships/ship_military_frigate.png` 96x96 | 9 |

## Not included (see README "Gaps")

Battleship and Flagship hulls; configuration variants of the same hull (e.g. a military Runner); NPC faction recolours; planet surface close-ups; shields; sound.
