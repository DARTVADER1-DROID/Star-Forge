# Weapon Mounting Specification

Hardpoint compatibility and equipment mass/power are **separate checks**. A weapon can be perfectly compatible with a hardpoint and still be rejected because the ship has no spare mass or power, and the opposite is also true. Report them as distinct failure reasons.

## Vocabulary
- **Size classes** (ordered): `small`=0, `medium`=1, `large`=2, `extra_large`=3.
- **Mount types**: `fixed`, `turret`.
- **Equipment mass**: sum of `mass` of installed weapons (and, later, other equipment). Limited by `stats.equipment_mass_capacity`. It is unrelated to hull `mass_empty` and unrelated to how many hardpoints exist.
- **Power**: sum of `power_draw` of installed weapons, limited by `stats.power_output`. (`energy_per_shot` is a separate runtime drain from the ship's energy pool and is not part of installation checks.)

## Install algorithm
Input: hull, current loadout, `hardpoint_id`, `weapon_id`. Run the checks **in this order** and stop at the first failure:

| # | Check | Rule | Error |
|---|---|---|---|
| 1 | Compatible hardpoint exists | the hull has a hardpoint with that `id` (when auto-placing: at least one free hardpoint passes checks 2-4) | `NO_SUCH_HARDPOINT` / `NO_COMPATIBLE_HARDPOINT` |
| 2 | Size supported | `size_rank(weapon.size) <= size_rank(hardpoint.max_size)` | `SIZE_TOO_LARGE` |
| 3 | Mount type compatible | `weapon.mount_type == hardpoint.mount_type` | `MOUNT_MISMATCH` |
| 3b | Restrictions | if `allowed_tags` present: weapon shares >= 1 tag; if `blocked_tags` present: weapon shares none | `RESTRICTED` |
| 4 | Equipment mass | `used_mass - replaced_mass + weapon.mass <= stats.equipment_mass_capacity` | `OVER_MASS` |
| 5 | Power | `used_power - replaced_power + weapon.power_draw <= stats.power_output` | `OVER_POWER` |

`replaced_*` is the mass/power of the weapon currently in that hardpoint (0 if empty), so swapping is evaluated as a replacement. Checks 1-3b are **geometry/compatibility**; 4-5 are **resource budget**. The install is atomic: either every check passes and the loadout changes, or nothing changes.

Firing arc: for `fixed` mounts the weapon points along `orientation_offset_deg` (arc 0). For `turret` mounts the aim direction is clamped to `orientation_offset_deg +/- arc_deg/2`; `arc_deg = 360` means unrestricted. The turret's rotation speed is the weapon's `turret_turn_rate_deg_s`.

## Reference implementation (C17)
```c
typedef enum { SF_SIZE_SMALL, SF_SIZE_MEDIUM, SF_SIZE_LARGE, SF_SIZE_XL } SfSize;
typedef enum { SF_MOUNT_FIXED, SF_MOUNT_TURRET } SfMount;
typedef enum { SF_OK, SF_NO_SUCH_HARDPOINT, SF_SIZE_TOO_LARGE, SF_MOUNT_MISMATCH,
               SF_RESTRICTED, SF_OVER_MASS, SF_OVER_POWER } SfInstallResult;

typedef struct { const char *id; int x, y; SfSize max_size; SfMount mount;
                 float offset_deg, arc_deg;
                 const char **allowed_tags; int n_allowed;
                 const char **blocked_tags; int n_blocked; } SfHardpoint;
typedef struct { const char *id; SfSize size; SfMount mount; float mass, power_draw;
                 const char **tags; int n_tags; } SfWeaponDef;

static bool sf_has_tag(const SfWeaponDef *w, const char *t) {
    for (int i = 0; i < w->n_tags; i++) if (strcmp(w->tags[i], t) == 0) return true;
    return false;
}

SfInstallResult sf_can_install(const SfHull *hull, const SfLoadout *lo,
                               int hp_index, const SfWeaponDef *w)
{
    if (hp_index < 0 || hp_index >= hull->n_hardpoints) return SF_NO_SUCH_HARDPOINT;
    const SfHardpoint *hp = &hull->hardpoints[hp_index];

    /* --- compatibility checks (independent of resources) --- */
    if (w->size > hp->max_size)  return SF_SIZE_TOO_LARGE;
    if (w->mount != hp->mount)   return SF_MOUNT_MISMATCH;
    if (hp->n_allowed) {
        bool any = false;
        for (int i = 0; i < hp->n_allowed; i++) any |= sf_has_tag(w, hp->allowed_tags[i]);
        if (!any) return SF_RESTRICTED;
    }
    for (int i = 0; i < hp->n_blocked; i++) if (sf_has_tag(w, hp->blocked_tags[i])) return SF_RESTRICTED;

    /* --- resource checks (independent of hardpoint geometry) --- */
    const SfWeaponDef *old = lo->installed[hp_index];          /* NULL if empty */
    float mass  = sf_loadout_mass(lo)  - (old ? old->mass : 0)       + w->mass;
    float power = sf_loadout_power(lo) - (old ? old->power_draw : 0) + w->power_draw;
    if (mass  > hull->equipment_mass_capacity) return SF_OVER_MASS;
    if (power > hull->power_output)            return SF_OVER_POWER;
    return SF_OK;
}
```

## Worked example (`loadout_player_example.json`)
Hull `hull_player_runner`: equipment mass capacity 24, power output 14.
| Step | Weapon | Hardpoint | Compatibility | Mass after | Power after |
|---|---|---|---|---|---|
| 1 | laser cannon (small, fixed, 4 mu, 3 pu) | `hp_wing_l` small fixed | OK | 4 / 24 | 3 / 14 |
| 2 | laser cannon | `hp_wing_r` | OK | 8 / 24 | 6 / 14 |
| 3 | pulse cannon (medium, fixed, 8 mu, 6 pu) | `hp_nose` medium fixed | OK | 16 / 24 | 12 / 14 |
| - | heavy cannon (large) | `hp_nose` | `SIZE_TOO_LARGE` (compatibility, before mass is even considered) | - | - |
| 4 | missile launcher (medium, fixed, 12 mu, 3 pu) replacing the pulse cannon | `hp_nose` | OK (replacement: 16 - 8 + 12) | 20 / 24 | 9 / 14 |
| - | railgun (extra_large) | `hp_nose` | `SIZE_TOO_LARGE` | - | - |
| - | any weapon pushing totals above 24 mu / 14 pu | any compatible mount | `OVER_MASS` / `OVER_POWER` (resource check, only reached after compatibility passed) | - | - |
| - | turret autocannon (small, turret) | `hp_wing_l` | `MOUNT_MISMATCH` | - | - |

## Runtime firing (informative)
Per weapon: cooldown `1 / fire_rate` s; each shot costs `energy_per_shot` from the ship energy pool; spawn `projectile_id` at the muzzle with speed `projectile_speed` along the weapon's world angle (plus random `spread_deg`); despawn when travelled distance exceeds `range`; apply `damage` of `damage_type` on hit within the projectile's `hit_radius`; explosive projectiles also apply damage within `blast_radius`.

## Unresolved design decision: fusion
Not specified, not implemented, no schema fields. See SHIP_LAYOUT_SPEC.md. Do not add a fusion code path until the design is decided.
